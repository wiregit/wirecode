/**
 * Provides basic implementation of pluggable look-and-feel for SwingX components together with a
 * mechanism to support custom component look-and-feels.
 */
package org.jdesktop.swingx.plaf.basic;

