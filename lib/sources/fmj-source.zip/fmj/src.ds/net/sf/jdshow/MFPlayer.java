package net.sf.jdshow;

import java.awt.Canvas;
import java.awt.Dimension;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import net.sf.fmj.utility.URLUtils;

import com.sun.jna.Native;

public class MFPlayer {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				try {
					//System.loadLibrary("jdshow");
					System.loadLibrary("JMediaFoundation");
				} catch (Throwable e) {
					e.printStackTrace();
				}

				File[] files = new File[]{		
						new File("C:/Users/mturkel/Downloads/big_buck_bunny_1080p_surround.avi"),
						new File("C:/Users/Public/Videos/Sample Videos/Wildlife.wmv"),				
						new File("C:/Users/mturkel/Documents/LimeWire/Saved/Creative_Commons_-_Remix_Culture.mpeg"),
						new File("C:/Users/mturkel/Documents/LimeWire/Saved/timelapse-overall.mp4"),
						new File("C:/Users/mturkel/Documents/LimeWire/Saved/big_buck_bunny_480p_surround-fix.avi")};
				CoInitializeEx();

				final Canvas canvas = new Canvas();
				canvas.setPreferredSize(new Dimension(500, 500));
				JFrame f = new JFrame("Real Frame");
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.add(canvas);
///f.addNotify();
f.pack();
f.setVisible(true);


				
				String url = URLUtils.extractValidPathFromFileUrl(URLUtils
						.createUrlStr(files[0]));
				System.out.println("(java) url = " + url);
				
				long hwnd = Native.getComponentID(canvas);
				 System.out.println("hwnd="+Long.toHexString(hwnd));
				int hr = startPlayer(url, hwnd);
				if (hr < 0) {
					// TODO do something
				}
				System.out.println("hr = " + hr);

				// } catch (MalformedURLException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
//for (int i = 0; i <100; i++){
				for (File file : files){
					System.out.println("can play " + file + "? " + 
							canPlayUrl(URLUtils.extractValidPathFromFileUrl(URLUtils.createUrlStr(file))));
				}
			}
			//}
		});
	}


	/**
	 * Starts video playback of the url file in the window hwnd. If a file is
	 * currently playing, the current player will be destroyed.
	 */
	public static native int startPlayer(String url, long hWnd);
	
	public static native void killPlayer();

	public static boolean canPlayUrl(String url){
		JFrame f = new JFrame();
		f.addNotify();
		boolean isPlayable = canPlayFile(url, Native.getComponentID(f));
		f.dispose();
		return isPlayable;
	}
	
	public static native boolean canPlayFile(String url, long hwnd);

	public static native int pause();
	
	public static native int resume();

	public static native int setVolume(float volume);
	
	public static native int getVolume(float[] volume);

	public static native int CoInitializeEx();

}
