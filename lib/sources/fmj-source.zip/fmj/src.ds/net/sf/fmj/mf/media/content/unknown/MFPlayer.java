package net.sf.fmj.mf.media.content.unknown;

import java.util.ArrayList;
import java.util.List;

//TODO: attach class to IMFPlayer pointer so that each instance has its own player.
class MFPlayer {
	
	static interface MFPlayerListener {
		public void statusChanged(int status);
	}

	//THESE CONSTANTS ARE USED IN NATIVE CODE.  DO NOT RENAME THEM.
	static final int ERROR = -1;
	static final int LOADED = 0;
	static final int STARTED = 1;
	static final int ENDED = 2;
		
	private volatile boolean statusUpdated = false;
	
	private final Object lock = new Object();
	private volatile int lastStatus;
	//Guarded by this
	private final List<MFPlayerListener> listeners = new ArrayList<MFPlayerListener>();


	/**
	 * Asynchronously starts video playback of the url file in the window hwnd. If a file is
	 * currently playing, the current player will be destroyed.
	 */
	public native int startPlayer(String url, long hWnd);
	


	/**
	 * Synchronously starts video playback of the url file in the window hwnd. If a file is
	 * currently playing, the current player will be destroyed.
	 */
	public int synchStartPlayer(String url, long hWnd) {
		synchronized (lock) {
			statusUpdated = false;
			lastStatus = ERROR;
			int hr = startPlayer(url, hWnd);
			// most unplayable files will be caught by the return value
			if (hr < 0) {
				return hr;
			}

			try {
				// for the remaining ones we wait for the callback
				while (!statusUpdated) {
					lock.wait();
				}
			} catch (InterruptedException e) {
				// do nothing
			}
			
			if (lastStatus == ERROR){
				killPlayer();
				return -1;
			}
			
			return 0;
		}
	}
	
	public native void killPlayer();
//
//	//TODO: this is ugly as hell and needs to be cleaned up.
//	public boolean canPlayFile(String url) {
//		JFrame f = new JFrame();
//		f.addNotify();
//		try {
//			synchronized (lock) {
//				statusUpdated = false;
//				lastStatus = ERROR;
//				int hr = startPlayer(url, Native.getComponentID(f));
//				//most unplayable files will be caught by the return value
//				if (hr < 0) {
//					System.err.println(false);
//					return false;
//				}
//				
//				try {
//					//for the remaining ones we wait for the callback
//					while (!statusUpdated) {
//						lock.wait();
//					}
//				} catch (InterruptedException e) {
//					//do nothing
//				}
//				System.err.println((lastStatus != ERROR));
//				return lastStatus != ERROR;
//			}
//		} finally {
//			f.dispose();
//			killPlayer();
//		}
//	}	

	public native int pause();

	public native int resume();
	
	/**
	 * 
	 * @param time Position in nanoseconds/100
	 * @return HRESULT
	 */
	public native int setPosition(long time);

	/**
	 * 
	 * @param time pointer to postion time in nanoseconds/100
	 * @return HRESULT
	 */
	public native int getPosition(long[] time);
	/**
	 * 
	 * @param duration pointer to the duration in nanoseconds/100
	 * @return HRESULT
	 */
	public native int getDuration(long[] duration);

	public native int setVolume(float volume);
	
	public native int getVolume(float[] volume);

	public native int initialize();
	
	//DO NOT CHANGE THIS METHOD NAME.  It is called by native code.
	private void statusChanged(int status){
		//synch start might be waiting for a status update - lock and notify
		synchronized (lock) {
			statusUpdated = true;
			lastStatus = status;
			lock.notifyAll();			
		}
		
		fireStatusChanged(status);
	}
	

	private synchronized void fireStatusChanged(int status) {
		for(MFPlayerListener listener :listeners){
			listener.statusChanged(status);
		}
	}

	private synchronized void addMFPlayerListener(MFPlayerListener listener) {
		listeners.add(listener);
	}
	private synchronized void removeMFPlayerListener(MFPlayerListener listener) {
		listeners.remove(listener);		
	}	
	

//	public static void main(String[] args) {
//		SwingUtilities.invokeLater(new Runnable() {
//
//			public void run() {
//				try {
//					//System.loadLibrary("jdshow");
//					System.loadLibrary("JMediaFoundation");
//				} catch (Throwable e) {
//					e.printStackTrace();
//				}
//
//				File[] files = new File[]{		
//						new File("C:/Users/mturkel/Downloads/big_buck_bunny_1080p_surround.avi"),
//						new File("C:/Users/Public/Videos/Sample Videos/Wildlife.wmv"),				
//						new File("C:/Users/mturkel/Videos/Building_On_The_Past.mov"),				
//						new File("C:/Users/mturkel/Documents/LimeWire/Saved/Creative_Commons_-_Remix_Culture.mpeg"),
//						new File("C:/Users/mturkel/Documents/LimeWire/Saved/timelapse-overall.mp4"),
//						new File("C:/Users/mturkel/Documents/LimeWire/Saved/big_buck_bunny_480p_surround-fix.avi")};
//				
//				MFPlayer player = new  MFPlayer();
//				player.initialize();
//
//				final Canvas canvas = new Canvas();
//				canvas.setPreferredSize(new Dimension(500, 500));
//				JFrame f = new JFrame("Real Frame");
//				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//				f.add(canvas);
//				f.pack();
//				f.setVisible(true);
//
//				String url = URLUtils.extractValidPathFromFileUrl(URLUtils
//						.createUrlStr(files[1]));
//				
//
//				long hwnd = Native.getComponentID(canvas);
//				System.out.println("(java) url = " + url);
//				System.out.println("Can play???");
//				if(player.canPlayFile(url)){
////				System.out.println("hwnd=" + Long.toHexString(hwnd));
//				int hr = player.startPlayer(url, hwnd);
////				if (hr < 0) {
////					// TODO do something
////				}
//				} else {
//					f.dispose();
//				}
////				System.out.println("hr = " + hr);
//
//
//			}
//		});
//	}
	
}
