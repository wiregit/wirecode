package net.sf.fmj.mf.media.content.unknown;


import java.awt.Canvas;
import java.awt.Component;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.swing.SwingUtilities;

import net.sf.fmj.concurrent.ExecutorServiceManager;
import net.sf.fmj.ejmf.toolkit.media.AbstractPlayer;
import net.sf.fmj.gui.controlpanelfactory.ControlPanelFactorySingleton;
import net.sf.fmj.media.AbstractGainControl;
import net.sf.fmj.utility.ExceptionUtils;
import net.sf.fmj.utility.LoggerSingleton;
import net.sf.fmj.utility.URLUtils;
import net.sf.jdshow.ComException;
import net.sf.jdshow.MFPlayer;

import com.sun.jna.Native;

/**
 * 
 * @author Ken Larson
 *
 */
public class Handler extends AbstractPlayer
{
	/**
	 * ExecutorService for all native calls.  This ensures that all native methods are called on the same thread.
	 */
	private static final ExecutorService executorService = ExecutorServiceManager.getExecutorService();

	private static final Logger logger = LoggerSingleton.logger;
	
	private static final boolean TRACE = true;
	
	private volatile String fileUrl;
	
	private volatile boolean isInitialized;
	
	private final ComponentListener myComponentListener = new MyComponentListener();
	
	
    public void setSource(final DataSource source) throws IncompatibleSourceException
	{
		Future future = executorService.submit(new Callable<Void>() {
			public Void call()throws Exception {
				if (TRACE)
					logger.fine("DataSource: " + source);

				if (!source.getLocator().getProtocol().equals("file"))
					throw new IncompatibleSourceException(
							"Only file URLs supported: " + source);

				// TODO: only handling file URLs right now.
				String path = URLUtils.extractValidPathFromFileUrl(source.getLocator().toExternalForm());
				if (path == null)
					throw new IncompatibleSourceException(
							"Unable to extract valid file path from URL: "
									+ source.getLocator().toExternalForm());

				try {
					// because Java thinks that /C: is a valid way to start a
					// path on Windows, we have to turn it
					// into something more normal.
					path = new File(path).getCanonicalPath();
				} catch (IOException e1) {
					final String msg = "Unable to get canonical path from "
							+ path + ": " + e1;
					logger.log(Level.WARNING, msg, e1);
					throw new IncompatibleSourceException(e1.toString() + " \n" + ExceptionUtils.getStackTrace(e1));
				}

				logger.info("Path: " + path);
				File file = new File(path);
				if(!file.exists()){
					throw new IncompatibleSourceException("File must exist to be played");
				}
				
				fileUrl = URLUtils.extractValidPathFromFileUrl(URLUtils.createUrlStr(file));

				try {
					System.loadLibrary("JMediaFoundation");
				} catch (Throwable e) {
					logger.log(Level.WARNING, "" + e, e);
					throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
				}

				try {
					int hr = MFPlayer.CoInitializeEx();
				} catch (Throwable e) {
					logger.log(Level.WARNING, "" + e, e);
					throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
				}
				
				boolean playable = MFPlayer.canPlayUrl(fileUrl);
				if(!playable){
					throw new IncompatibleSourceException("File not MediaFoundation playable: " + fileUrl);
				}

				Handler.super.setSource(source);
				return null;
			}
		});
		
		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
		} catch (ExecutionException e) {
			if (e.getCause() instanceof IncompatibleSourceException) {
				throw (IncompatibleSourceException) e.getCause();
			} else {
				logger.log(Level.WARNING, "" + e, e);
				throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
			}
		}

	}

	//@Override
	public void doPlayerClose()
	{
	}

	//@Override
	public boolean doPlayerDeallocate()
	{
		visualComponent.removeComponentListener(myComponentListener);
		visualComponent = null;
		Future future = executorService.submit(new Runnable(){
			public void run() {
				MFPlayer.killPlayer();
			}			
		});

		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			//we still want everything else to be deallocated even if something goes wrong here
			return true;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			//we still want everything else to be deallocated even if something goes wrong here
			return true;
		}
		return true;
	}

	//@Override
	public boolean doPlayerPrefetch()
	{ 
		return true;
	}

	//@Override
	public boolean doPlayerRealize()
	{
	    
		return true;
	}
	



	//@Override
	public void doPlayerSetMediaTime(final Time t)
	{
		Future future = executorService.submit(new Runnable(){
			public void run() {
				//TODO: set media time
			}
		});
		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
		}
	}

	//@Override
	public float doPlayerSetRate(final float rate)
	{
		Future<Float> future = executorService.submit(new Callable<Float>(){
			public Float call() {
		logger.fine("Handler.doPlayerSetRate " + rate);

			//TODO setRate
		return rate;
			}
		});
		
		try {
			return future.get().floatValue();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return getRate();
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return getRate();
		}
	}

	//@Override
	public boolean doPlayerStop()
	{
		Future<Boolean> future = executorService.submit(new Callable<Boolean>() {					
			public Boolean call() {
				logger.info("Handler.doPlayerStop");
				int hr = MFPlayer.pause();
				if (failed(hr)) {
					return false;
				}
				return true;	
			}
		});
		
		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return false;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return false;
		}
	}

	//@Override
	public boolean doPlayerSyncStart(final Time t)
	{
		Future<Boolean> future = executorService.submit(new Callable<Boolean>() {					
					public Boolean call() {
						logger.info("Handler.doPlayerSyncStart" + t);
						if (isInitialized) {
							int hr = MFPlayer.resume();

							if (failed(hr)) {
								return false;
							}
							return true;
						} else {
							return false;
						}
					}				
		});
		
		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return false;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return false;
		}
	}

	// @Override
	public Time getPlayerDuration()
 {
		// TODO getPlayerDuration
		return DURATION_UNKNOWN;
	}

	// @Override
	public Time getMediaTime()
 {
		// TODO getPlayerDuration
		return DURATION_UNKNOWN;
	}



	// @Override
	public Time getPlayerStartLatency()
	{
		return new Time(0);
	}

	//visualComponent can only be accessed on the EDT
	private Canvas visualComponent;
	
	//@Override
	public Component getVisualComponent()
	{
		if(visualComponent == null){
			visualComponent = new Canvas();

			visualComponent.addComponentListener(myComponentListener);
		}
		
		return visualComponent;
	}

	private class MyComponentListener implements ComponentListener
	{

		public void componentHidden(ComponentEvent e)
		{
			//do nothing
		}

		public void componentMoved(ComponentEvent e)
		{
			//do nothing
			
		}

		public void componentResized(ComponentEvent e)
		{
			logger.fine("componentResized");
			initializeVideo();	
		}

		public void componentShown(ComponentEvent e)
		{
			logger.fine("componentShown");
			initializeVideo();
			
		}

	}
	

	//only called on EDT
	private void initializeVideo()
	{

		
		assert(SwingUtilities.isEventDispatchThread());
		
		if (!visualComponent.isDisplayable()) {
			// avoid java.lang.IllegalStateException: Component must be
			// displayable exception
			return;
		}
		
		if(isInitialized){
			return;
		}
		
		final long hwnd = Native.getComponentID(visualComponent);
	
		
		Future<Boolean> future = executorService.submit(new Callable<Boolean>() {
			public Boolean call() {						
				try {			
					final int hr = MFPlayer.startPlayer(fileUrl, hwnd);
					if (failed(hr))								
						throw new ComException(hr);
				} catch (ComException e) {							
					logger.log(Level.WARNING, "" + e, e);							
					return false;						
				}						
				// visualComponentBound = true;						
				return true;					
			}


		});

		try {
			boolean success = future.get();
			if(success){
				setGainControl(new MFGainControl());
				setState(Started);
				postStartEvent();
			}
			isInitialized = success;
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
		}

	}


    public Component getControlPanelComponent() {
        Component c = super.getControlPanelComponent();

        if( c == null ) {
            c = ControlPanelFactorySingleton.getInstance().getControlPanelComponent(this);
            setControlPanelComponent(c);
        }

        return c;
    }
    
	private boolean failed(int hr) {
		// TODO is this right?
		return hr < 0;
	}	
    
    private class MFGainControl extends AbstractGainControl {
    	private static final long DS_MINIMUM_VOLUME = -10000;

		public float getLevel() {
			Future<Float> future = executorService.submit(new Callable<Float>() {
						
				public Float call() throws ComException{							
					float[] vol = new float[1];
					int hr = MFPlayer.getVolume(vol);
					if(failed(hr)){
						throw new ComException(hr);
					}
					return vol[0];
				}
			});
			
			try {
				return future.get();
			} catch (InterruptedException e) {
				logger.log(Level.WARNING, "basicAudio.get_Volume failed", e);
				ExceptionUtils.reportOrReturn(e);
				//TODO: what to return here?
				return 0;
			} catch (ExecutionException e) {
				logger.log(Level.WARNING, "basicAudio.get_Volume failed", e);
				ExceptionUtils.reportOrReturn(e.getCause());
				//TODO: what to return here?
				return 0;
			}
		}

		public float setLevel(final float level) {
			Future<Float> future = executorService.submit(new Callable<Float>() {
				public Float call() throws ComException {			
					int hr = MFPlayer.setVolume(level);	
					if(failed(hr)){
						throw new ComException(hr);
					}
					return level;
				}				
			});
			
			try {
				future.get();
				notifyListenersGainChangeEvent();
				return level;
			} catch (InterruptedException e) {
				logger.log(Level.WARNING, "basicAudio.put_Volume failed", e);
				ExceptionUtils.reportOrReturn(e);
				//TODO: what to return here?
				return level;
			} catch (ExecutionException e) {
				logger.log(Level.WARNING, "basicAudio.put_Volume failed", e);
				ExceptionUtils.reportOrReturn(e.getCause());
				//TODO: what to return here?
				return level;
			}
		}
	
    }

}
