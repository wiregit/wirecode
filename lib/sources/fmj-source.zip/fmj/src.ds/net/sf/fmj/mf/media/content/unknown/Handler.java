package net.sf.fmj.mf.media.content.unknown;


import java.awt.Canvas;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.protocol.DataSource;

import net.sf.fmj.concurrent.ExecutorServiceManager;
import net.sf.fmj.ejmf.toolkit.media.AbstractPlayer;
import net.sf.fmj.gui.controlpanelfactory.ControlPanelFactorySingleton;
import net.sf.fmj.media.AbstractGainControl;
import net.sf.fmj.mf.media.content.unknown.MFPlayer.MFPlayerListener;
import net.sf.fmj.utility.ExceptionUtils;
import net.sf.fmj.utility.LoggerSingleton;
import net.sf.fmj.utility.URLUtils;
import net.sf.jdshow.ComException;

import com.sun.jna.Native;

/**
 * 
 * @author Ken Larson
 *
 */
public class Handler extends AbstractPlayer
{
	/**
	 * ExecutorService for all native calls.  This ensures that all native methods are called on the same thread.
	 */
	private static final ExecutorService executorService = ExecutorServiceManager.getExecutorService();

	private static final Logger logger = LoggerSingleton.logger;
	
	private static final boolean TRACE = true;
	
	private volatile String fileUrl;	
		
	private final MFPlayer mfPlayer = new MFPlayer();

	private final Canvas renderer;
	
	public Handler(Canvas renderer){
		this.renderer = renderer;
	}
	
	
    public void setSource(final DataSource source) throws IncompatibleSourceException
	{
		Future future = executorService.submit(new Callable<Void>() {
			public Void call()throws Exception {
				if (TRACE)
					logger.fine("DataSource: " + source);

				//TODO: this patch checking logic should be shared with the DS handler
				if (!source.getLocator().getProtocol().equals("file"))
					throw new IncompatibleSourceException(
							"Only file URLs supported: " + source);

				String path = URLUtils.extractValidPathFromFileUrl(source.getLocator().toExternalForm());
				if (path == null)
					throw new IncompatibleSourceException(
							"Unable to extract valid file path from URL: "
									+ source.getLocator().toExternalForm());

				try {
					path = new File(path).getCanonicalPath();
				} catch (IOException e1) {
					final String msg = "Unable to get canonical path from "
							+ path + ": " + e1;
					logger.log(Level.WARNING, msg, e1);
					throw new IncompatibleSourceException(e1.toString() + " \n" + ExceptionUtils.getStackTrace(e1));
				}

				logger.info("Path: " + path);
				File file = new File(path);
				if(!file.exists()){
					throw new IncompatibleSourceException("File must exist to be played");
				}
				
				fileUrl = URLUtils.extractValidPathFromFileUrl(URLUtils.createUrlStr(file));

				try {
					System.loadLibrary("JMediaFoundation");
				} catch (Throwable e) {
					logger.log(Level.WARNING, "" + e, e);
					throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
				}

				try {
					int hr = mfPlayer.initialize();
				} catch (Throwable e) {
					logger.log(Level.WARNING, "" + e, e);
					throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
				}
				long hwnd = Native.getComponentID(renderer);
				int result = mfPlayer.synchStartPlayer(fileUrl, hwnd);
				if(failed(result)){
					throw new IncompatibleSourceException("File not MediaFoundation playable: " + fileUrl);
				}

				Handler.super.setSource(source);
				return null;
			}
		});
		
		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
		} catch (ExecutionException e) {
			if (e.getCause() instanceof IncompatibleSourceException) {
				throw (IncompatibleSourceException) e.getCause();
			} else {
				logger.log(Level.WARNING, "" + e, e);
				throw new IncompatibleSourceException(e.toString() + " \n" + ExceptionUtils.getStackTrace(e));
			}
		}

		setGainControl(new MFGainControl());
		postStartEvent();
	}

	//@Override
	public void doPlayerClose()
	{
	}

	//@Override
	public boolean doPlayerDeallocate()
	{
		Future future = executorService.submit(new Runnable(){
			public void run() {
				mfPlayer.killPlayer();
			}			
		});

		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			//we still want everything else to be deallocated even if something goes wrong here
			return true;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			//we still want everything else to be deallocated even if something goes wrong here
			return true;
		}
		return true;
	}

	//@Override
	public boolean doPlayerPrefetch()
	{ 
		return true;
	}

	//@Override
	public boolean doPlayerRealize()
	{
	    
		return true;
	}
	



	//@Override
	public void doPlayerSetMediaTime(final Time t)
	{
		logger.info("Handler.doPlayerSetMediaTime");
		
		Future future = executorService.submit(new Runnable(){
			public void run() {
				try {
					long mfTime = t.getNanoseconds() / 100; 

					int hr = mfPlayer.setPosition(mfTime);
					if (failed(hr))
						throw new ComException(hr);

				} catch (ComException e) {
					logger.log(Level.WARNING, "" + e, e);
					// TODO: handle
				}
			}
		});
		try {
			future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
		}
	}

	//@Override
	public float doPlayerSetRate(final float rate)
	{
		Future<Float> future = executorService.submit(new Callable<Float>(){
			public Float call() {
		logger.fine("Handler.doPlayerSetRate " + rate);

			//TODO setRate
		return rate;
			}
		});
		
		try {
			return future.get().floatValue();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return getRate();
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return getRate();
		}
	}

	//@Override
	public boolean doPlayerStop()
	{
		Future<Boolean> future = executorService.submit(new Callable<Boolean>() {					
			public Boolean call() {
				logger.info("Handler.doPlayerStop");
				int hr = mfPlayer.pause();
				if (failed(hr)) {
					return false;
				}
				return true;	
			}
		});
		
		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return false;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return false;
		}
	}

	//@Override
	public boolean doPlayerSyncStart(final Time t)
	{
		Future<Boolean> future = executorService.submit(new Callable<Boolean>() {					
					public Boolean call() {
						logger.info("Handler.doPlayerSyncStart" + t);

						int hr = mfPlayer.resume();

						if (failed(hr)) {
							return false;
						}
						return true;

					}				
		});
		
		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return false;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return false;
		}
	}

	// @Override
	public Time getPlayerDuration() {
		Future<Time> future = executorService.submit(new Callable<Time>() {
			public Time call() {
				try {
					long[] duration = new long[1];

					int hr = mfPlayer.getDuration(duration);
					if (failed(hr))
						throw new ComException(hr);

					return new Time(duration[0] * 100);
				} catch (ComException e) {
					logger.log(Level.WARNING, "" + e, e);
					return DURATION_UNKNOWN;
				}
			}
		});

		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return DURATION_UNKNOWN;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return DURATION_UNKNOWN;
		}
	}

	// @Override
	public Time getMediaTime() {
		Future<Time> future = executorService.submit(new Callable<Time>() {
			public Time call() {
				try {
					long[] position = new long[1];

					int hr = mfPlayer.getPosition(position);
					if (failed(hr))
						throw new ComException(hr);

					return new Time(position[0] * 100);
				} catch (ComException e) {
					logger.log(Level.WARNING, "" + e, e);
					return DURATION_UNKNOWN;
				}
			}
		});

		try {
			return future.get();
		} catch (InterruptedException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e);
			return DURATION_UNKNOWN;
		} catch (ExecutionException e) {
			logger.log(Level.WARNING, "" + e, e);
			ExceptionUtils.reportOrReturn(e.getCause());
			return DURATION_UNKNOWN;
		}
	}

	// @Override
	public Time getPlayerStartLatency()
	{
		return new Time(0);
	}

	
	//@Override
	public Component getVisualComponent()
	{
		return renderer;
	}
	
    public Component getControlPanelComponent() {
        Component c = super.getControlPanelComponent();

        if( c == null ) {
            c = ControlPanelFactorySingleton.getInstance().getControlPanelComponent(this);
            setControlPanelComponent(c);
        }

        return c;
    }
    
	private boolean failed(int hr) {
		return hr < 0;
	}	
    
    private class MFGainControl extends AbstractGainControl {
    	private static final long DS_MINIMUM_VOLUME = -10000;

		public float getLevel() {
			Future<Float> future = executorService.submit(new Callable<Float>() {
						
				public Float call() throws ComException{							
					float[] vol = new float[1];
					int hr = mfPlayer.getVolume(vol);
					if(failed(hr)){
						throw new ComException(hr);
					}
					return vol[0];
				}
			});
			
			try {
				return future.get();
			} catch (InterruptedException e) {
				logger.log(Level.WARNING, "basicAudio.get_Volume failed", e);
				ExceptionUtils.reportOrReturn(e);
				//TODO: what to return here?
				return 0;
			} catch (ExecutionException e) {
				logger.log(Level.WARNING, "basicAudio.get_Volume failed", e);
				ExceptionUtils.reportOrReturn(e.getCause());
				//TODO: what to return here?
				return 0;
			}
		}

		public float setLevel(final float level) {
			Future<Float> future = executorService.submit(new Callable<Float>() {
				public Float call() throws ComException {			
					int hr = mfPlayer.setVolume(level);	
					if(failed(hr)){
						throw new ComException(hr);
					}
					return level;
				}				
			});
			
			try {
				future.get();
				notifyListenersGainChangeEvent();
				return level;
			} catch (InterruptedException e) {
				logger.log(Level.WARNING, "basicAudio.put_Volume failed", e);
				ExceptionUtils.reportOrReturn(e);
				//TODO: what to return here?
				return level;
			} catch (ExecutionException e) {
				logger.log(Level.WARNING, "basicAudio.put_Volume failed", e);
				ExceptionUtils.reportOrReturn(e.getCause());
				//TODO: what to return here?
				return level;
			}
		}
	
    }
    
    private class MediaFoundationListener implements MFPlayerListener {

		public void statusChanged(int status) {
			switch (status){
			case MFPlayer.ERROR:
				break;
			case MFPlayer.LOADED:
				setState(Prefetched);
				break;
			case MFPlayer.STARTED:
				setState(Started);
				break;
			case MFPlayer.ENDED:
				break;
			}
		}
    	
    }

}
