package net.sf.fmj.media.processor.unknown;


/**
 * 
 * @author Ken Larson
 *
 */
public class Handler extends net.sf.fmj.media.content.unknown.Handler
{

	public Handler()
	{
		super(PROCESSOR);
	}

}
