package net.sf.fmj.filtergraph.model;

public class FilterGraphModel {

	private final NodeModel root;

	public FilterGraphModel(final NodeModel root) {
		super();
		this.root = root;
	}

	public NodeModel getRoot() {
		return root;
	}


	
	
}
