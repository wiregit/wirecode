package net.sf.jdshow;

public class IBasicAudio extends IUnknown{

	public IBasicAudio(long ptr) {
		super(ptr);
	}
	
	/**
	 * volume ranges from -10,000 to 0.
	 */
	public native int put_Volume(long volume);
	
	public native int get_Volume(long[] volume);
	
	static native GUID Init_IID(GUID guid);
}
