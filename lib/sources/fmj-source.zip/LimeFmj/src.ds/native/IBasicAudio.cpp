#include <jni.h>
#include <windows.h>
#include <dshow.h>
#include "net_sf_jdshow_IBasicAudio.h"
#include "jniutils.h"
#include "utils.h"

JNIEXPORT jint JNICALL Java_net_sf_jdshow_IBasicAudio_put_1Volume
  (JNIEnv *pEnv, jobject o, jlong volume)
{
	IBasicAudio *pBasicAudio = (IBasicAudio *) getPeerPtr(pEnv, o);
	return pBasicAudio->put_Volume(volume);

}

JNIEXPORT jint JNICALL Java_net_sf_jdshow_IBasicAudio_get_1Volume
  (JNIEnv *pEnv, jobject o, jlongArray a)
{
	jlong *p = GetLongArr(pEnv, a);

	IBasicAudio *pBasicAudio = (IBasicAudio *) getPeerPtr(pEnv, o);
	int hr = pBasicAudio->get_Volume((long *)p);
	ReleaseLongArr(pEnv, a, p);
	return hr;
}


JNIEXPORT jobject JNICALL Java_net_sf_jdshow_IBasicAudio_Init_1IID
  (JNIEnv *pEnv, jclass, jobject jGuid)
{
	fromGUID(pEnv, IID_IBasicAudio, jGuid);
	return jGuid;
}


