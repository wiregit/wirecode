package com.jacob.com;

import com.jacob.test.BaseTestCase;

/**
 * Test some of the Dispatch utility methods
 * <p>
 * May need to run with some command line options (including from inside
 * Eclipse). Look in the docs area at the Jacob usage document for command line
 * options.
 */
public class DispatchTest extends BaseTestCase {

	/**
	 * Dummy test until someone gets their act together
	 */
	public void testDispatch() {
		// what should we test
	}
}
