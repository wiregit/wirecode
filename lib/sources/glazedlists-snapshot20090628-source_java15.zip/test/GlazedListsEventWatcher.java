import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.event.ListEvent;
import ca.odell.glazedlists.event.ListEventListener;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.swing.EventTableModel;

public class GlazedListsEventWatcher {

	public static class Thing
	{
		static private int nextNumber = 0;

		private final String name;
		private final int number;

		public String getName() {
			return name;
		}
		public int getNumber() {
			return number;
		}

		public Thing(String name) {
			super();
			this.name = name;
			this.number = nextNumber++;
		}
	}

	public static JButton createActionButton(String name, ActionListener al)
	{
		JButton btn = new JButton(name);
		btn.addActionListener(al);
		return btn;
	}

	public static void addBatch(EventList<Thing> thingList, int N)
	{
		List<Thing> batch = new ArrayList<Thing>();
		for (int i = 0; i < N; ++i)
			batch.add(new Thing("greebly"));

		thingList.addAll(batch);
	}

	public static void main(String[] args) {
	    final EventList<Thing> thingList = new BasicEventList<Thing>();
//	    final EventList<Thing> thingList = GlazedLists.threadSafeList(new BasicEventList<Thing>());
		thingList.addListEventListener(new ListEventListener<Thing>() {
		    public void listChanged(ListEvent<Thing> listChanges) {
		        System.out.println("LISTEVENT " + System.currentTimeMillis() + listChanges);
		    }
		});
		// build a JTable
		String[] propertyNames = new String[] {"name", "number"};
		String[] columnLabels = new String[] {"Name", "Number"};
		TableFormat<Thing> tf = GlazedLists.tableFormat(Thing.class, propertyNames, columnLabels);
		EventTableModel<Thing> etm = new EventTableModel<Thing>(thingList, tf);
		JTable t = new JTable(etm);

		etm.addTableModelListener(new TableModelListener() {
			public String whichType(TableModelEvent evt)
			{
				switch (evt.getType())
				{
				case TableModelEvent.DELETE: return "DELETE";
				case TableModelEvent.INSERT: return "INSERT";
				case TableModelEvent.UPDATE: return "UPDATE";
				default: return "??? ("+evt.getType()+")";
				}
			}
			public void tableChanged(TableModelEvent evt) {
				System.out.println(System.currentTimeMillis()+": "+whichType(evt)+" ["+evt.getFirstRow()+","+evt.getLastRow()+"]");
			}
		});

		// place the table in a JFrame
		JFrame f = new JFrame("GlazedLists Event Watcher");
		JPanel panel = new JPanel();
		Box vbox = Box.createVerticalBox();
		f.add(panel); panel.add(vbox);

		vbox.add(new JScrollPane(t));
		Box hbox = Box.createHorizontalBox();
		vbox.add(hbox);
		for (final int i : Arrays.asList(1,10,100))
		{
			hbox.add(createActionButton("Add "+i, new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {
					addBatch(thingList, i);
				}
			}));
		}
		hbox.add(createActionButton("Clear", new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				thingList.clear();
			}
		}));
		hbox.add(createActionButton("RetainAll(1 thing)", new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				if (thingList.size() > 0)
				{
					List<Thing> thingsToKeep = new ArrayList<Thing>();
					Random r = new Random();
					thingsToKeep.add(thingList.get(r.nextInt(thingList.size())));
					thingList.retainAll(thingsToKeep);
				}
			}
		}));
		hbox.add(createActionButton("RemoveAll(middle half)", new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				if (thingList.size() > 3)
				{
					int sz = thingList.size();

					List<Thing> thingsToRemove = new ArrayList<Thing>();
					thingsToRemove.addAll(thingList.subList(sz/4, 3*sz/4));
					thingList.removeAll(thingsToRemove);
				}
			}
		}));

		// show the frame
		f.pack();
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
