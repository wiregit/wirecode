package org.mozilla.browser.examples;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JSplitPane;
import javax.swing.TransferHandler;

import net.sourceforge.iharder.Base64;

import org.mozilla.browser.MozillaPanel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

/**
 * Drag and drop from/to Mozilla browser
 */
public class Example11_DnD {

    public static void main(String[] args) {
        //Create and set up the window.
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 800);

        JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

        //drop a color into the mozilla area
        JColorChooser b = new JColorChooser();
        b.setColor(Color.RED);
        b.setDragEnabled(true);
        b.setTransferHandler(new Base64TransferHandler());
        b.setMinimumSize(new Dimension(500,100));
        sp.add(b);

        final MozillaPanel moz = new MozillaPanel() {
            @Override
            public void onDrop(Node source, Node target, Object data) {
                if (data instanceof Color) {
                    Color c = (Color) data;
                    Document doc = target.getOwnerDocument();
                    Element e1 = doc.createElement("table");
                    Element e2 = doc.createElement("tr");
                    Element e3 = doc.createElement("td");
                    Text t = doc.createTextNode("dnd example");

                    int i = c.getRed()*256*256+c.getGreen()*256+c.getBlue();
                    String s = Integer.toHexString(i);
                    e3.setAttribute("bgcolor", "#"+s);

                    e3.appendChild(t);
                    e2.appendChild(e3);
                    e1.appendChild(e2);
                    target.getParentNode().appendChild(e1);

                }
            }
        };
        moz.load("about:");
        moz.setMinimumSize(new Dimension(500,350));
        moz.setPreferredSize(new Dimension(500,650));

        sp.add(moz);

        sp.setDividerLocation(0.7d);
        frame.getContentPane().add(sp, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    /**
     * Adds support for text/unicode support by encoding
     * the data object into base64 for each transferable
     */
    public static class Base64TransferHandler extends TransferHandler {

        public Base64TransferHandler() {
            super("color");
        }

        public Transferable createTransferable(JComponent comp) {
            Transferable t = super.createTransferable(comp);
            return new Base64Transferable(t);
        }
    }

    /**
     * Adds support for text/unicode support by encoding
     * the data object into base64
     */
    public static class Base64Transferable implements Transferable {

        private final Transferable t;

        public Base64Transferable(Transferable t) {
            this.t = t;
        }

        public Object getTransferData(DataFlavor flavor)
            throws
                UnsupportedFlavorException,
                IOException
        {
            if (flavor!=null &&
                flavor.equals(DataFlavor.stringFlavor) &&
                !t.isDataFlavorSupported(DataFlavor.stringFlavor))
            {
                //if text/unicode dataflavor is not supported
                //get the data
                DataFlavor[] dfs = t.getTransferDataFlavors();
                Object d = t.getTransferData(dfs[0]);

                //serialize to byte stream
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ObjectOutputStream os = new ObjectOutputStream(bos);
                os.writeObject(d);
                os.close();
                bos.close();

                //encode into string with base64
                return Base64.encodeBytes(bos.toByteArray());
            } else {
                return t.getTransferData(flavor);
            }
        }
        public boolean isDataFlavorSupported(DataFlavor flavor) {
            if (flavor==null) return false;
            if (flavor.equals(DataFlavor.stringFlavor)) return true;
            return t.isDataFlavorSupported(flavor);
        }
        public DataFlavor[] getTransferDataFlavors() {
            if (t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return t.getTransferDataFlavors();
            } else {
                DataFlavor[] fs = t.getTransferDataFlavors();

                DataFlavor[] allfs = new DataFlavor[fs.length+1];
                allfs[0] = DataFlavor.stringFlavor;
                System.arraycopy(fs, 0, allfs, 1, fs.length);
                return allfs;
            }
        }
    }


}
