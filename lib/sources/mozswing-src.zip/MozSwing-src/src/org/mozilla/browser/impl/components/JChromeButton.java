package org.mozilla.browser.impl.components;

/**
 * Chrome toolbar button
 */
public class JChromeButton extends JImageButton
{

    private static final long serialVersionUID = -7335320862277898283L;

    public JChromeButton(String imgName,
                         String toolTip)
    {
        super(null,
              String.format("%sNormal.png",imgName),
              String.format("%sPressed.png",imgName),
              String.format("%sRollover.png",imgName),
              String.format("%sDisabled.png",imgName));
        setToolTipText(toolTip);
        setFocusable(false);
        setBorderPainted(false);
    }

}
