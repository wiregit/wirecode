package org.mozilla.browser.examples;

import org.mozilla.browser.MozillaAutomation;
import org.mozilla.browser.MozillaWindow;

/**
 * Submit form using POST method
 */
public class Example08_Post {
    public static void main(String[] args) throws Exception {
        MozillaWindow win = new MozillaWindow();
        win.setSize(500, 600);
        win.setVisible(true);

        boolean failed =
            MozillaAutomation.
            blockingLoad(win,
                     //url
                     "http://search.yahoo.com/search",
                     //POST data
                     "p=mozswing&ei=UTF-8");

        if (failed)
            System.err.println("load failed");
        else
            System.err.println("load succeeded");
    }
}
