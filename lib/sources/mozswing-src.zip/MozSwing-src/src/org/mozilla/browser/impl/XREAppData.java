package org.mozilla.browser.impl;

import java.io.File;

import org.mozilla.xpcom.IXREAppData;

/**
 * Describes entry point for XUL Application
 * (content of the application.ini file)
 *
 * http://developer.mozilla.org/en/docs/XUL_Application_Packaging
 */
public class XREAppData implements IXREAppData {

    public String getVendor() {
        return "MozSwing";
    }

    public String getName() {
        return "MozSwing";
    }

    public int getFlags() {
        return 0;
    }

    public File getDirectory() {
        return null;
    }

    public String getID() {
        return "mozswing@mozswing.org";
    }

    public String getVersion() {
        return "1.x";
    }

    public String getBuildID() {
        return "1.x";
    }

    public String getCopyright() {
        return "Copyright (c) 2007-2008 MozSwing";
    }

}
