package org.mozilla.browser;

import static org.mozilla.browser.MozillaExecutor.isMozillaThread;
import static org.mozilla.browser.MozillaExecutor.mozAsyncExec;
import static org.mozilla.browser.MozillaExecutor.mozSyncExecQuiet;
import static org.mozilla.browser.MozillaExecutor.swingAsyncExec;
import static org.mozilla.browser.XPCOMUtils.qi;
import static org.mozilla.interfaces.nsIWebBrowserChrome.CHROME_DEFAULT;
import static org.mozilla.interfaces.nsIWebBrowserChrome.CHROME_LOCATIONBAR;
import static org.mozilla.interfaces.nsIWebBrowserChrome.CHROME_STATUSBAR;
import static org.mozilla.interfaces.nsIWebBrowserChrome.CHROME_TOOLBAR;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.Callable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mozilla.browser.impl.ChromeAdapter;
import org.mozilla.browser.impl.MozillaContainer;
import org.mozilla.browser.impl.WindowCreator;
import org.mozilla.browser.impl.components.JChromeButton;
import org.mozilla.dom.NodeFactory;
import org.mozilla.interfaces.nsIDOMDocument;
import org.mozilla.interfaces.nsIWebBrowserChrome;
import org.mozilla.interfaces.nsIWebNavigation;
import org.w3c.dom.Document;

/**
 * Browser component for embedding into more complex Swing GUI.
 *
 * <p> MozillaWindow is a {@link JPanel} subclass suitable for
 * embedding into larger swing application. However, you might
 * need to adapt toolbar, statusbar or popup handling to fulfill
 * requirements of your application.
 *
 * <p>We use sane defaults, therefore creating a browser
 * in your code is as simple as:
 * <code>
 * <pre>
 *   JFrame f = new JFrame();
 *   f.setSize(500, 600);
 *   MozillaPanel p = new MozillaPanel();
 *   p.load("about:");
 *   f.getContentPane().add(p);
 *   f.setVisible(true);
 * </pre>
 * </code>
 *
 * <!--FIXME
 * <p>The result is displayed on the picture bellow:</p>
 * <img src="http://sourceforge.net/dbimage.php?id=150841"></img>
 * <p>
 * -->
 */
public class MozillaPanel
    extends JPanel
{

    /**
     * Behaviour for toolbar and statusbar visibility.
     */
    public static enum VisibilityMode {
        /**
         * Mozilla (or javascript in webpage) decides
         * if toolbar and statusbar are visible or hidden.
         */
        DEFAULT,
        /**
         * Be always visible, ignoring mozilla when it says
         * to hide toolbar or statusbar
         */
        FORCED_VISIBLE,
        /**
         * Be always hidden, ignoring mozilla when it says
         * to show toolbar or statusbar.
         */
        FORCED_HIDDEN
    }

    private static final long serialVersionUID = 1L;

    static Log log = LogFactory.getLog(MozillaPanel.class);

    protected final VisibilityMode toolbarVisMode;
    protected final VisibilityMode statusbarVisMode;

    protected JToolBar toolbar;
    protected JButton backButton, forwardButton, reloadButton, stopButton, goButton;
    protected JTextField urlBar;
    protected MozillaContainer mozContainer;
    protected JTextField statusField;

    protected MozillaPanel parentPanel;
    protected IMozillaWindow containerWin;

    private ChromeAdapter chromeAdapter;

    private boolean attachNewBrowserOnCreation;

    private String pendingUriToLoad, pendingContentToLoad, pendingContentUriToLoad;

    private Dimension initialPreferredSize;

    private static int DEFAULT_WIDTH = 300;
    private static int DEFAULT_HEIGHT = 300;

    /**
     * true, if window/tab title should be
     * updated on mozilla callback
     */
    protected boolean updateTitle = true;

    /**
     * Creates a new MozillaPanel with default
     * toolbar and statusbar visibility mode.
     */
    public MozillaPanel()
    {
        this(null, true, null, null);
    }

    /**
     * Creates a new MozillaPanel with default
     * toolbar and statusbar visibility mode.
     */
    public MozillaPanel(boolean attachNewBrowserOnCreation)
    {
        this(null, attachNewBrowserOnCreation, null, null);
    }

    /**
     * Creates a new MozillaPanel with default
     * toolbar and statusbar visibility mode.
     *
     * @param toolbarVisMode toolbar visibility mode
     * @param statusbarVisMode status visibility mode
     */
    public MozillaPanel(VisibilityMode toolbarVisMode,
                        VisibilityMode statusbarVisMode)
    {
        this(null, true, toolbarVisMode, statusbarVisMode);
    }

    /**
     * Internal constructor.
     *
     * @param containerWin window that contains this mozilla panel
     * @param attachNewBrowserOnCreation true if a new mozilla browser
     *   should be immediately attached. Used with false when pre-creating
     *   popups in {@link WindowCreator}
     * @param toolbarVisMode toolbar visibility mode
     * @param statusbarVisMode status visibility mode
     */
    public MozillaPanel(IMozillaWindow containerWin,
                        boolean attachNewBrowserOnCreation,
                        VisibilityMode toolbarVisMode,
                        VisibilityMode statusbarVisMode)
    {
        this.containerWin = containerWin;
        this.attachNewBrowserOnCreation = attachNewBrowserOnCreation;
        MozillaInitialization.initialize();

        this.toolbarVisMode = toolbarVisMode!=null ? toolbarVisMode : VisibilityMode.DEFAULT;
        this.statusbarVisMode = statusbarVisMode!=null ? statusbarVisMode : VisibilityMode.DEFAULT;

        this.initialPreferredSize = new Dimension(DEFAULT_WIDTH,DEFAULT_HEIGHT);

        createChrome();
    }

    /**
     * Internal method.
     * Related to pre-creating of swing windows for {@link WindowCreator}.
     */
    public void attachNewBrowser() {
        assert isMozillaThread();
        WindowCreator.attachBrowser(MozillaPanel.this, CHROME_DEFAULT, null);
    }

    /**
     * Notification, when mozilla browser is being added
     * into the given swing window.
     *
     * @param chromeAdapter mozilla browser being added
     *   into swing window/panel
     * @param parentChromeAdapter mozilla browser of parent
     * window, see {@link MozillaPanel#getParentPanel()}
     */
    public void onAttachBrowser(final ChromeAdapter chromeAdapter, final ChromeAdapter parentChromeAdapter) {
        assert isMozillaThread();
        assert chromeAdapter!=null;
        assert this.chromeAdapter==null;

        this.chromeAdapter = chromeAdapter;
        //notify swing canvas component, that the native area is ready
        mozContainer.onAttachBrowser(chromeAdapter);

        swingAsyncExec(new Runnable() { public void run() {
            final boolean showToolbar;
            {
                VisibilityMode vm = toolbarVisMode;
                if (vm==VisibilityMode.DEFAULT && parentChromeAdapter!=null)
                    vm = parentChromeAdapter.getPanel().getToolbarVisibilityMode();
                switch (vm) {
                    case FORCED_VISIBLE:
                        showToolbar = true;
                        break;
                    case FORCED_HIDDEN:
                        showToolbar = false;
                        break;
                    case DEFAULT:
                    default:
                        showToolbar = (chromeAdapter.getChromeFlags() & (CHROME_TOOLBAR|CHROME_LOCATIONBAR))!=0;
                }
            }
            toolbar.setVisible(showToolbar);

            final boolean showStatusbar;
            {
                VisibilityMode vm = statusbarVisMode;
                if (vm==VisibilityMode.DEFAULT && parentChromeAdapter!=null)
                    vm = parentChromeAdapter.getPanel().getStatusbarVisibilityMode();
                switch (vm) {
                case FORCED_VISIBLE:
                    showStatusbar = true;
                    break;
                case FORCED_HIDDEN:
                    showStatusbar = false;
                    break;
                case DEFAULT:
                default:
                    showStatusbar =
                        (chromeAdapter.getChromeFlags() & CHROME_STATUSBAR)!=0 &&
                        (chromeAdapter.getChromeFlags() & nsIWebBrowserChrome.CHROME_OPENAS_DIALOG)==0;
                }
            }
            statusField.setVisible(showStatusbar);

            if (parentPanel!=null) {
                Dimension d = parentPanel.getSize(); //FIXME is parentPanel has parentWindow
                onSetOuterSize(d.width, d.height);
            } else {
                onSetPreferredOuterSize(initialPreferredSize);
            }
            adjustLocation(chromeAdapter.getChromeFlags());

            if (pendingUriToLoad!=null)
                load(pendingUriToLoad);
            else if (pendingContentToLoad!=null)
                loadHTML(pendingContentToLoad, pendingContentUriToLoad);
            pendingUriToLoad = pendingContentToLoad = pendingContentUriToLoad = null;
        }});
    }

    /**
     * Notification when mozilla browser is being removed from swing window.
     */
    public void onDetachBrowser() {
        assert isMozillaThread();
        this.chromeAdapter = null;
        mozContainer.onDetachBrowser();
    }

    protected void createChrome() {

//        if ((chromeMask & CHROME_MENUBAR)!=0) {
//            createMenu();
//        }

        setLayout(new BorderLayout());
        createToolbar();
        toolbar.setVisible(false);
        createMozillaPanel();
        createStatusbar();
        statusField.setVisible(false);
    }

    protected void createToolbar()
    {
        toolbar = new JToolBar();
        toolbar.setFloatable(false); //bug #18229
        add(toolbar, BorderLayout.NORTH);
        backButton = new JChromeButton("back", mt.t("MozillaPanel.Tooltip_Back")); //$NON-NLS-1$ //$NON-NLS-2$
        backButton.setEnabled(false);
        backButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            goBack();
        }});
        toolbar.add(backButton);
        forwardButton = new JChromeButton("forward", mt.t("MozillaPanel.Tooltip_Forward")); //$NON-NLS-1$ //$NON-NLS-2$
        forwardButton.setEnabled(false);
        forwardButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            goForward();
        }});
        toolbar.add(forwardButton);
        reloadButton = new JChromeButton("reload", mt.t("MozillaPanel.Tooltip_Reload")); //$NON-NLS-1$ //$NON-NLS-2$
        reloadButton.setEnabled(false);
        reloadButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            reload();
        }});
        toolbar.add(reloadButton);
        stopButton = new JChromeButton("stop", mt.t("MozillaPanel.Tooltip_Stop")); //$NON-NLS-1$ //$NON-NLS-2$
        stopButton.setEnabled(false);
        stopButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            stop();
        }});
        toolbar.add(stopButton);

        //enclose the textfield into a panel,
        //to keep the default height
        JPanel p = new JPanel();
        p.setLayout(new GridBagLayout());
        urlBar = new JTextField();
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0;
        c.weightx = 1.0; c.weighty = 0.0;
        c.fill = GridBagConstraints.HORIZONTAL;
        p.add(urlBar, c);
        urlBar.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            String uri = urlBar.getText();
            load(uri);
        }});
        toolbar.add(p);

        goButton = new JChromeButton("go", mt.t("MozillaPanel.Tooltip_Go")); //$NON-NLS-1$ //$NON-NLS-2$
        goButton.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
            String uri = urlBar.getText();
            load(uri);
        }});
        toolbar.add(goButton);
    }

    protected void createMozillaPanel()
    {
        //enclose the awt canvas component with mozilla
        //(MozCanvas) into a jpanel (MozContainer).
        //otherwise relative positioning in a layout of the
        //parent component and focus traversal do not work
        //properly
        mozContainer = new MozillaContainer();
        add(mozContainer, BorderLayout.CENTER);
    }

    @Override
    public void addNotify() {
        super.addNotify();

        if (MozillaInitialization.isInitialized()) {
            if (attachNewBrowserOnCreation) {
                Runnable r = new Runnable() { public void run() {
                    attachNewBrowser();
                }};
                mozAsyncExec(r);
            }
        }
    }

    @Override
    public void removeNotify() {
        super.removeNotify();
    }

    protected void createStatusbar()
    {
        statusField = new JTextField(""); //$NON-NLS-1$
        statusField.setEditable(false);
        statusField.setFocusable(false);
        add(statusField, BorderLayout.SOUTH);
    }

    protected void adjustLocation(long chromeMask){
        if (containerWin!=null) {
            MozillaPanel parentPanel = getParentPanel();
            if (parentPanel==null) return;
            IMozillaWindow parentContainerWin = parentPanel.getContainerWindow();
            if (parentContainerWin==null || !parentContainerWin.isShowing()) return;

            Point pos = parentContainerWin.getLocationOnScreen();
            if ((chromeMask & (nsIWebBrowserChrome.CHROME_CENTER_SCREEN))!=0) {
                Dimension parentSize = parentContainerWin.getSize();
                Point p = new Point(parentSize.width/2, parentSize.height/2);
                Dimension size = containerWin.getSize();
                p.translate(-size.width/2, -size.height/2);
                log.trace(String.format("adjustLocation: %d, %d", p.x, p.y)); //$NON-NLS-1$
                pos.translate(p.x, p.y);
                if (pos.x<0) pos.x=0;
                if (pos.y<0) pos.y=0;
            } else {
                //shift right,down by the height of title bar
                Insets insets = getInsets();
                pos.translate(insets.top, insets.top);
            }
            containerWin.setLocation(pos);
        } else {
            //usually can't move, so ignore by default
        }
    }

    /**
     * Triggers loading of previous page in the session history.
     * For blocking version, see {@link MozillaAutomation#blockingBack(MozillaPanel)}
     */
    public void goBack() {
        mozAsyncExec(new Runnable() { public void run() {
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.goBack();
        }});
    }

    /**
     * Triggers loading of next page in the session history.
     * For blocking version, see {@link MozillaAutomation#blockingForward(MozillaPanel)}
     */
    public void goForward() {
        if (chromeAdapter==null) return;
        mozAsyncExec(new Runnable() { public void run() {
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.goForward();
        }});
    }

    /**
     * Triggers re-loading of current page.
     * For blocking version, see {@link MozillaAutomation#blockingReload(MozillaPanel)}
     */
    public void reload() {
        if (chromeAdapter==null) return;
        mozAsyncExec(new Runnable() { public void run() {
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.reload(nsIWebNavigation.LOAD_FLAGS_NONE);
        }});
    }

    /**
     * Stops loading of the page, if running.
     */
    public void stop() {
        if (chromeAdapter==null) return;
        mozAsyncExec(new Runnable() { public void run() {
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.stop(nsIWebNavigation.STOP_ALL);
        }});
    }

    /**
     * Triggers loading of web page with the given url
     * For blocking version, see {@link MozillaAutomation#blockingLoad(MozillaPanel, String)}
     *
     * @param uri uri to be loaded
     */
    public void load(final String uri) {
        if (uri==null || uri.length()==0) return;
        if (chromeAdapter==null) {
            pendingUriToLoad = uri;
            return;
        }

        mozAsyncExec(new Runnable() { public void run() {
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.loadURI(uri, nsIWebNavigation.LOAD_FLAGS_NONE, null, null, null);
        }});
    }

    /**
     * Triggers loading of web page with the give content.
     * For blocking version, see {@link MozillaAutomation#triggerLoadHTML(MozillaPanel, String, String)}
     *
     * @param content HTML content to be loaded
     */
    public void loadHTML(final String content) {
        loadHTML(content, null);
    }

    /**
     * Triggers loading of web page with the give content.
     * Sets the given url as origin of the content.
     * For blocking version, see {@link MozillaAutomation#triggerLoadHTML(MozillaPanel, String, String)}
     *
     * @param content HTML content to be loaded
     * @param asUrl alias URL
     */
    public void loadHTML(final String content, final String asUrl) {
        if (content==null) return;
        if (chromeAdapter==null) {
            pendingContentToLoad = content;
            pendingContentUriToLoad = asUrl;
            return;
        }

        mozAsyncExec(new Runnable() { public void run() {
            MozillaAutomation.triggerLoadHTML(MozillaPanel.this, content, asUrl);
        }});
    }

    /**
     * Returns the current URL.
     *
     * @return url of current webpage
     */
    public String getUrl() {
        if (chromeAdapter==null) {
            return null;
        }
        return
            mozSyncExecQuiet(new Callable<String>() { public String call() {
                return MozillaAutomation.getCurrentURI(MozillaPanel.this);
            }});
    }

    /**
     * execute javascript code inside the current web page
     *
     * @param script javascript code to execute
     *
     * @return value returned from evaluated javascript code
     *   (not implemented ATM)
     */
    public Object jsexec(String script) {
        if (chromeAdapter==null) return null;
        return MozillaAutomation.executeJavascript(this, script);
    }

    /**
     * Return swing component with the mozilla
     * rendering area
     *
     * @return (MozSwing internal) swing component
     * with mozilla rendering area
     */
    public MozillaContainer getMozillaContainer() {
        return mozContainer;
    }

    /**
     * Returns mozilla browser in this swing window
     *
     * @return embedding adapter of mozilla browser in this swing window
     */
    public ChromeAdapter getChromeAdapter() {
        return chromeAdapter;
    }

    /**
     * Sets parent panel of this panel
     *
     * <p>From a  webpage, child window can be created
     * by opening an HTML popup or chrome window
     * using the openWindow() javascript function.
     *
     * @param parentPanel parent browser panel
     */
    public void setParentPanel(MozillaPanel parentPanel) {
        this.parentPanel = parentPanel;
    }
    /**
     * Returns parent panel of this panel.
     *
     * <p>From a  webpage, child window can be created
     * by opening an HTML popup or chrome window
     * using the openWindow() javascript function.
     *
     * @return parent browser panel
     */
    public MozillaPanel getParentPanel() {
        return parentPanel;
    }
    public void setContainerWindow(IMozillaWindow parentWin) {
        this.containerWin = parentWin;
    }
    public IMozillaWindow getContainerWindow() {
        return containerWin;
    }

    /**
     * Request to show text in statusbar.
     * Callback from mozilla embedding code.
     *
     * @param text text for statusbar
     */
    public void onSetStatus(String text) {
        statusField.setText(text);
    }
    /**
     * Enable/disable the back button.
     * Callback from mozilla embedding code.
     *
     * @param enabled true to enable the button,
     *   otherwise false
     */
    public void onEnableBackButton(boolean enabled) {
        backButton.setEnabled(enabled);
    }
    /**
     * Request to enable/disable the forward button.
     * Callback from mozilla embedding code.
     *
     * @param enabled true to enable the button,
     *   otherwise false
     */
    public void onEnableForwardButton(boolean enabled) {
        forwardButton.setEnabled(enabled);
    }
    /**
     * Enable/disable the reload button.
     * Callback from mozilla embedding code.
     *
     * @param enabled true to enable the button,
     *   otherwise false
     */
    public void onEnableReloadButton(boolean enabled) {
        reloadButton.setEnabled(true);
    }
    /**
     * Enable/disable the stop button.
     * Callback from mozilla embedding code.
     *
     * @param enabled true to enable the button,
     *   otherwise false
     */
    public void onEnableStopButton(boolean enabled) {
        stopButton.setEnabled(enabled);
    }
    /**
     * Request to set text in urlbar.
     * Callback from mozilla embedding code.
     *
     * @param url text to show in urlbar
     */
    public void onSetUrlbarText(String url) {
        urlBar.setText(url);
    }
    /**
     * Request to resize the browser window.
     *
     * <p>See {@link JFrame#setSize(int, int)}
     *
     * @param w requested outer window width (including window border)
     * @param h requested outer window height (including window border)
     */
    public void onSetOuterSize(int w, int h) {
        if (containerWin!=null) {
            containerWin.setSize(w, h);
        } else {
            //usually can't resize, so ignore by default
            log.debug("ignored onSetOuterSize in mozpanel"); //$NON-NLS-1$
        }
    }
    /**
     * Request to set preferred size the browser window.
     *
     * <p>See {@link JFrame#setPreferredSize(Dimension}
     *
     * @param d preferred outer dimension (including window border)
     */
    public void onSetPreferredOuterSize(Dimension d) {
        if (containerWin!=null) {
            containerWin.setPreferredSize(d);
        } else {
            //usually can't resize, so ignore by default
            log.debug("ignored onSetOuterPreferredSize in mozpanel"); //$NON-NLS-1$
        }
    }
    /**
     * Request to resize the browser window.
     * Callback from mozilla embedding code.
     *
     * <p>See {@link JFrame#setSize(int,int)}
     *
     * @param w requested inner window width (without window border)
     * @param h requested inner window height (without window border)
     */
    public void onSetInnerSize(int w, int h) {
        if (containerWin!=null) {
            Insets insets = containerWin.getInsets();
            w = w + insets.left + insets.right;
            h = h + insets.top + insets.bottom;
            containerWin.setSize(w, h);
        } else {
            //usually can't resize, so ignore by default
            log.debug("ignored onSetInnerSize in mozpanel"); //$NON-NLS-1$
        }
    }

    /**
     * By default, MozillaPanel updates title of the
     * window or tab where it is embedded.
     * Using this method you can enable/disable
     * that behaviour.
     *
     * @param updateTitle flag enabling/disabling
     *  updating of the window or tab title
     */
    public void setUpdateTitle(boolean updateTitle){
        this.updateTitle = updateTitle;
    }
    /**
     * Request to set title for the browser window.
     * Callback from mozilla embedding code.
     *
     * <p>See {@link JFrame#setTitle(String)}
     *
     * @param title window title
     */
    public void onSetTitle(String title) {
        if (updateTitle){
            setTitle(title);
        }
    }
    public void setTitle(String title) {
        //check if we are contained in a JTabbedPane
        Component tab = this;
        Container tabPane = this.getParent();
        while(tabPane != null && !(tabPane instanceof JTabbedPane)) {
            tab = tabPane;
            tabPane = tabPane.getParent();
        }

        if (tabPane!=null) {
            JTabbedPane tabPane2 = (JTabbedPane) tabPane;
            int idx = tabPane2.indexOfComponent(tab);
            if (idx>=0) {
                tabPane2.setTitleAt(idx, title);
            }
        } else {
            if (containerWin!=null) {
                containerWin.setTitle(title);
            }
        }
    }
    public String getTitle() {
        //check if we are contained in a JTabbedPane
        Component tab = this;
        Container tabPane = this.getParent();
        while(tabPane != null && !(tabPane instanceof JTabbedPane)) {
            tab = tabPane;
            tabPane = tabPane.getParent();
        }

        if (tabPane!=null) {
            JTabbedPane tabPane2 = (JTabbedPane) tabPane;
            int idx = tabPane2.indexOfComponent(tab);
            if (idx>=0) {
                return tabPane2.getTitleAt(idx);
            } else {
                log.error("Unknown tab index"); //$NON-NLS-1$
                return ""; //$NON-NLS-1$
            }
        } else {
            if (containerWin!=null) {
                return containerWin.getTitle();
            } else {
                log.error("Unknown window type"); //$NON-NLS-1$
                return ""; //$NON-NLS-1$
            }
        }
    }

    private boolean isFirstShow = true;

    /**
     * Request to show/hide the browser window
     * Callback from mozilla embedding code.
     *
     * <p>See {@link JFrame#setVisible(boolean)}
     *
     * @param visibility window visibility
     */
    public void onSetVisible(boolean visibility) {
        if (visibility && isFirstShow) {
            adjustLocation(chromeAdapter.getChromeFlags());
            isFirstShow = false;
        }

        if (containerWin!=null) {
            if (containerWin.isVisible()!=visibility) {
                containerWin.setVisible(visibility);
            }
        } else {
            //subclass should override this method
            log.debug("Ignoring mozilla request to change visibility of the panel"); //$NON-NLS-1$
        }
    }
    /**
     * Notification when document loading starts
     * Callback from mozilla embedding code.
     */
    public void onLoadingStarted() {}
    /**
     * Notification when document loading end.
     * Callback from mozilla embedding code.
     */
    public void onLoadingEnded() {}
    /**
     * Request to close the browser window.
     * Callback from mozilla embedding code.
     */
    public void onCloseWindow() {
        if (containerWin!=null) {
            onSetVisible(false);
            containerWin.dispose();
        } else {
            //subclass should override this method
            log.debug("Ignoring mozilla request to close the panel"); //$NON-NLS-1$
        }
    }

    /**
     * Request to dispatch an synthetized AWT event.
     *
     * <p>Used to emulate AWT mouse/key events using
     * DOM mouse/key events.
     *
     * @param e AWT event to be dispatched
     */
    public void onDispatchEvent(AWTEvent e) {
        super.processEvent(e);
    }

    /**
     * Returns DOM document of the currently
     * loaded webpage.
     *
     * <p>This is a live DOM tree, so modifying
     * the tree is directly changing the webpage.
     *
     * @return DOM document of current webpage
     */
    public Document getDocument() {
        if (chromeAdapter==null)
            return null;
        else {
            return
            mozSyncExecQuiet(new Callable<Document>() { public Document call() {
                nsIDOMDocument nsdoc = chromeAdapter.getWebBrowser().getContentDOMWindow().getDocument();
                return (Document) NodeFactory.getNodeInstance(nsdoc);
            }});
        }
    }

    /**
     * Sets the initial preferred size of the Mozilla panel
     * used when the browser is attached
     *
     * @param preferredSize intial preferred size
     */
    public void setInitialPreferredSize(Dimension preferredSize){
        this.initialPreferredSize = preferredSize;
    }

    /**
     * Returns current toolbar visibility mode.
     * See {@link VisibilityMode}
     *
     * @return toolbar visibility mode
     */
    public VisibilityMode getToolbarVisibilityMode() { return toolbarVisMode; }
    /**
     * Returns current statusbar visibility mode.
     * See {@link VisibilityMode}
     *
     * @return statusbar visibility mode
     */
    public VisibilityMode getStatusbarVisibilityMode() { return statusbarVisMode; }
    /**
     * Returns chrome toolbar containing back, forward,
     * reload, stop buttons, urlbar and go botton.
     *
     * @return chrome toolbar
     */
    public JToolBar getToolbar() { return toolbar; }
    /**
     * Returns chrome statusbar.
     *
     * @return chrome statusbar
     */
    public JTextField getStatusbar() { return statusField; }

//    @SuppressWarnings("all") //javadoc only - how? //$NON-NLS-1$
//    public static void main(String[] args) {
//        JFrame frame = new JFrame();
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(500, 600);
//
//        MozillaPanel moz = new MozillaPanel();
//        //moz.load(MozillaTest.resolveURL(""));
//        moz.load("about:"); //$NON-NLS-1$
//
//        frame.getContentPane().add(moz);
//        frame.setVisible(true);
//    }

}
