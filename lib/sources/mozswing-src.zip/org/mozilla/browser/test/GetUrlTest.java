package org.mozilla.browser.test;

import static org.mozilla.browser.MozillaAutomation.blockingLoad;

public class GetUrlTest extends MozillaTest {

    public void testGetUrl() {
        assertFalse(blockingLoad(win, "about:"));
        String url = win.getUrl();
        assertEquals(url, "about:");

        assertFalse(blockingLoad(win, "about:config"));
        url = win.getUrl();
        assertEquals(url, "about:config");
    }
}
