package org.mozilla.browser.test;

import static org.mozilla.browser.MozillaAutomation.sleep;

import org.mozilla.browser.MozillaPanel;
import org.mozilla.browser.IMozillaWindow;
import org.mozilla.browser.MozillaAutomation;
import org.mozilla.browser.MozillaPanel;
import org.mozilla.browser.MozillaWindow;

public class ChromeVisibilityTest extends MozillaTest {

    @Override
    protected void setUp() throws Exception {}
    @Override
    protected void tearDown() throws Exception {}

    public void testForcedVisible()
    {
        MozillaPanel moz = new MozillaPanel(MozillaPanel.VisibilityMode.FORCED_VISIBLE, MozillaPanel.VisibilityMode.FORCED_VISIBLE);
        MozillaWindow win = new MozillaWindow(moz);
        win.setBounds(200, 200, 300, 300);
        win.setVisible(true);

        MozillaAutomation.blockingLoadHTML(moz, "<html><body><h3>Forced showing of toolbar and statusbar</h3></body></html>", null); //$NON-NLS-1$
        sleep(2000);

        win.setVisible(false);
        win.dispose();
    }

    public void testForcedHidden()
    {
        MozillaPanel moz = new MozillaPanel(MozillaPanel.VisibilityMode.FORCED_HIDDEN, MozillaPanel.VisibilityMode.FORCED_HIDDEN);
        MozillaWindow win = new MozillaWindow(moz);
        win.setBounds(200, 200, 300, 300);
        win.setVisible(true);

        MozillaAutomation.blockingLoadHTML(moz, "<html><body><h3>Forced hiding of toolbar and statusbar</h3></body></html>", null); //$NON-NLS-1$
        sleep(2000);

        win.setVisible(false);
        win.dispose();
    }

    public void testHideShow()
    {
        MozillaPanel moz = new MozillaPanel(MozillaPanel.VisibilityMode.FORCED_VISIBLE, MozillaPanel.VisibilityMode.FORCED_VISIBLE);
        MozillaWindow win = new MozillaWindow(moz);
        win.setBounds(200, 200, 300, 300);
        win.setVisible(true);

        MozillaAutomation.blockingLoadHTML(moz, "<html><body><h3>Hidding and showing toolbar and statusbar</h3></body></html>", null); //$NON-NLS-1$
        sleep(2000);

        moz.getToolbar().setVisible(false);
        moz.getStatusbar().setVisible(false);
        sleep(2000);

        moz.getToolbar().setVisible(true);
        moz.getStatusbar().setVisible(true);
        sleep(2000);

        win.setVisible(false);
        win.dispose();
    }


//    public void testForcedHiddenPopup()
//    {
//        MozillaWindow win = new MozillaWindow(IMozillaWindow.VisibilityMode.FORCED_VISIBLE, IMozillaWindow.VisibilityMode.FORCED_VISIBLE);
//        MozillaPanel moz = win.getMozPanel();
//        win.setBounds(200, 200, 300, 300);
//        win.setVisible(true);
//
////        MozillaAutomation.blockingLoadHTML(moz, "<html><body><h3>Forced hiding of toolbar and statusbar</h3></body></html>");
////        sleep(2000);
//        assertFalse(blockingLoad(moz, resolveURL("popup.html")));
//
//        //open popup
//        mozAsyncExec(new Runnable() { public void run() {
//            assertFalse(click(moz, "Open1"));
//        }});
//        //we had to leave the previous mozilla code block so that
//        //the mozilla thread can complete the window opening
//
//        //test if the popup is openned
//        assertNotNull(waitForWindowWithTitle("Popup1", 3000));
//
//        //close popup from main window
//        mozSyncExec(new Runnable() { public void run() {
//            assertFalse(click(moz, "Close1"));
//        }});
//        //test if the popup is closed
//        assertNull(waitForNoWindowWithTitle("Popup1", 3000));
//
//
//        win.setVisible(false);
//        win.dispose();
//    }

}
