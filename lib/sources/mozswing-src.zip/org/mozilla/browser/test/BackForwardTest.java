package org.mozilla.browser.test;

import static org.mozilla.browser.MozillaAutomation.blockingBack;
import static org.mozilla.browser.MozillaAutomation.blockingForward;
import static org.mozilla.browser.MozillaAutomation.blockingLoad;

public class BackForwardTest extends MozillaTest {

    public void testHistory() {
        assertFalse(blockingLoad(moz, "about:")); //$NON-NLS-1$
        assertFalse(blockingLoad(moz, "about:cache")); //$NON-NLS-1$
        //single move
        assertFalse(blockingBack(moz));
        assertFalse(blockingForward(moz));

        assertFalse(blockingLoad(moz, "about:config")); //$NON-NLS-1$
        //double move
        assertFalse(blockingBack(moz));
        assertFalse(blockingBack(moz));
        assertFalse(blockingForward(moz));
        assertFalse(blockingForward(moz));
    }

}
