package org.mozilla.browser.test;

import static org.mozilla.browser.MozillaAutomation.blockingLoad;
import static org.mozilla.browser.MozillaAutomation.click;
import static org.mozilla.browser.MozillaAutomation.getOpennedWindows;
import static org.mozilla.browser.MozillaAutomation.waitForNoWindowWithTitle;
import static org.mozilla.browser.MozillaAutomation.waitForNumWindowsWithTitle;
import static org.mozilla.browser.MozillaAutomation.waitForWindowWithTitle;
import static org.mozilla.browser.MozillaExecutor.mozAsyncExec;
import static org.mozilla.browser.MozillaExecutor.mozSyncExec;

import java.awt.Window;
import java.util.List;
import java.util.concurrent.Callable;

import javax.swing.SwingUtilities;

import junit.framework.Assert;

import org.mozilla.browser.MozillaExecutor;
import org.mozilla.browser.MozillaInitialization;
import org.mozilla.browser.MozillaPanel;

public class PopupTest extends MozillaTest {

    private static final String TEST_URL = resolveURL("popup.html"); //$NON-NLS-1$

    public void testOpen() {
        assertFalse(blockingLoad(moz, TEST_URL));

        //open popup
        mozAsyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Open1")); //$NON-NLS-1$
        }});
        //we had to leave the previous mozilla code block so that
        //the mozilla thread can complete the window opening

        //test if the popup is openned
        assertNotNull(waitForWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$

        //close popup from main window
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Close1")); //$NON-NLS-1$
        }});
        //test if the popup is closed
        assertNull(waitForNoWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$

        //open popup
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Open1")); //$NON-NLS-1$
        }});
        //close popup from the popup itself
        final MozillaPanel childMoz = waitForWindowWithTitle("Popup1", 3000); //$NON-NLS-1$
        Assert.assertNotNull(childMoz);
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(childMoz, "Close")); //$NON-NLS-1$
        }});
        //test if the popup is closed
        assertNull(waitForNoWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$
    }

    public void testDouble() {
        testOpen();
        flushSwingJobs();
        testOpen();
    }

    public void testMixedOrder() {
        assertFalse(blockingLoad(moz, TEST_URL));

        //open popup
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Open1")); //$NON-NLS-1$
            assertFalse(click(moz, "Open2")); //$NON-NLS-1$
        }});
        //test if the popups are openned
        assertNotNull(waitForWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$
        assertNotNull(waitForWindowWithTitle("Popup2", 3000)); //$NON-NLS-1$
        //close popup2
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Close2")); //$NON-NLS-1$
        }});
        //test if the popups are openned/closed
        assertNotNull(waitForWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$
        assertNull(waitForNoWindowWithTitle("Popup2", 3000)); //$NON-NLS-1$
        //close popup1
        mozSyncExec(new Runnable() { public void run() {
            assertFalse(click(moz, "Close1")); //$NON-NLS-1$
        }});
        //test if the popups are closed
        assertNull(waitForNoWindowWithTitle("Popup1", 3000)); //$NON-NLS-1$
        assertNull(waitForNoWindowWithTitle("Popup2", 3000)); //$NON-NLS-1$
    }

    //needs higher default value in
    //WindowCreator.ensurePrecreatedWindows()
    public void dis_testManyOpens()
        throws Exception
    {
        assertFalse(blockingLoad(moz, TEST_URL));

        log.debug("opening..."); //$NON-NLS-1$
        MozillaExecutor.swingSyncExec(new Runnable() { public void run() {
            MozillaInitialization.getWinCreator().ensurePrecreatedWindows(20);
        }});
        for (int i=0; i<20; i++) {
            //open popup
            mozSyncExec(new Runnable() { public void run() {
                assertFalse(click(moz, "Open3")); //$NON-NLS-1$
            }});
            flushMozillaJobs();
            flushSwingJobs();
        }
        log.debug("openned"); //$NON-NLS-1$

        log.debug("closing..."); //$NON-NLS-1$
        List<MozillaPanel> panels =
            waitForNumWindowsWithTitle("Popup3", 20, 10000); //$NON-NLS-1$
        assertEquals(20, panels.size());
        for (MozillaPanel panel : panels) {
            Window win = SwingUtilities.getWindowAncestor(panel);
            win.setVisible(false);
            win.dispose();
        }
        assertNull(waitForNoWindowWithTitle("Popup3", 10000)); //$NON-NLS-1$

        panels = mozSyncExec(new Callable<List<MozillaPanel>>() { public java.util.List<MozillaPanel> call() throws Exception {
            return getOpennedWindows();
        }});
        assertEquals(1, panels.size());
        log.debug("closed"); //$NON-NLS-1$
    }

    public void testZZZ() {
        //to ensure nothing crashed before
    }
}
