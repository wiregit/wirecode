package org.mozilla.browser.test;

import static org.mozilla.browser.MozillaAutomation.blockingLoadHTML;
import static org.mozilla.browser.MozillaAutomation.sleep;

import java.net.URL;

import org.mozilla.browser.impl.FileUtils;

public class LoadHTMLTest extends MozillaTest {


    public void testLoadHTML() throws Exception {
        final String u1 = resolveURL("bigpage1.html"); //$NON-NLS-1$
        String page1 = new String(FileUtils.readStream(new URL(u1).openStream()), "UTF-8"); //$NON-NLS-1$
        final String u2 = resolveURL("bigpage2.html"); //$NON-NLS-1$
        String page2 = new String(FileUtils.readStream(new URL(u2).openStream()), "UTF-8"); //$NON-NLS-1$

//        final String[] url1 = new String[1];
//        final String[] url2 = new String[1];
//        mozSyncExec(new Runnable(){ public void run() {
//            nsIURIFixup ufix = XPCOMUtils.create("@mozilla.org/docshell/urifixup;1", nsIURIFixup.class);
//            url1[0] = ufix.createFixupURI(u1, nsIURIFixup.FIXUP_FLAGS_MAKE_ALTERNATE_URI).getSpec();
//            url2[0] = ufix.createFixupURI(u2, nsIURIFixup.FIXUP_FLAGS_MAKE_ALTERNATE_URI).getSpec();
//        }});
//

        //users reported loading 20 times with loadHTML significantly
        //slows down the whole mozilla
        int N = 0;

        //load as data: url
        for (int i=0; i<N; i++) {
            assertFalse(blockingLoadHTML(moz, page1, null));
            sleep(100);
            assertFalse(blockingLoadHTML(moz, page2, null));
            sleep(100);
        }

        //load from stream
        for (int i=0; i<N; i++) {
            assertFalse(blockingLoadHTML(moz, page1, u1));
            sleep(100);
            assertFalse(blockingLoadHTML(moz, page2, u2));
            sleep(100);
        }
    }

    public void testAsyncLoadHTML() throws Exception {
        final String u1 = resolveURL("bigpage1.html"); //$NON-NLS-1$
        String page1 = new String(FileUtils.readStream(new URL(u1).openStream()), "UTF-8"); //$NON-NLS-1$
        final String u2 = resolveURL("bigpage2.html"); //$NON-NLS-1$
        String page2 = new String(FileUtils.readStream(new URL(u2).openStream()), "UTF-8"); //$NON-NLS-1$

        int N = 50;
        for (int i=0; i<N; i++) {
            moz.loadHTML(page1, u1);
            moz.loadHTML(page2, u2);
        }
    }
}
