package org.mozilla.browser;

import static org.mozilla.browser.XPCOMUtils.asyncProxy;
import static org.mozilla.browser.XPCOMUtils.proxy;

import java.util.concurrent.Callable;
import java.util.concurrent.Semaphore;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mozilla.browser.impl.CocoaUtils;
import org.mozilla.browser.impl.GtkUtils;
import org.mozilla.interfaces.nsIAppShell;
import org.mozilla.interfaces.nsIComponentManager;
import org.mozilla.interfaces.nsIRunnable;
import org.mozilla.interfaces.nsISupports;
import org.mozilla.xpcom.Mozilla;

/**
 * Executor for running jobs on mozilla thread.
 */
public class MozillaExecutor3 {

    static Log log = LogFactory.getLog(MozillaExecutor3.class);

    /**
     * The single executor for all mozilla jobs.
     */
    private static final MozillaExecutor3 singleton = new MozillaExecutor3();

    /**
     * Thread where mozilla runs.
     */
    private static Thread mozillaThread;

    /**
     * Lock held until mozilla is successfully initialized
     */
    private final Semaphore initLock;

    public static enum Platform { OSX, Linux, Win32 };

    static final Platform platform;

    static {
        String osname = System.getProperty("os.name");
        if ("Mac OS X".equals(osname)) {
            platform = Platform.OSX;
        } else if ("Linux".equals(osname)) {
            platform = Platform.Linux;
        } else {
            platform = Platform.Win32;
        }
    }


    private MozillaExecutor3() {
        try {
            this.initLock = new Semaphore(1);
            this.initLock.acquire();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Synchronously executes a task for mozilla initialization.
     */
    protected static void mozInit(final RunnableEx task)
        throws MozillaException
    {
        if (platform==Platform.OSX) {
            //on OS X:
            // - we have to execute the initialization
            //   on the AppKit thread
            // - we do not need to spin the event loop
            //   using nsIAppShell.run(), because Swing
            //   will spin AppKit event loop, and therefore
            //   also the Mozilla event loop
            try {
                System.loadLibrary("cocoautils");
                CocoaUtils.runOnAppKitThread(task);
                mozillaThread = CocoaUtils.appkitThread;
                assert mozillaThread!=null;
            } catch (Throwable t) {
                throw new MozillaException(t);
            }
        } else {
            //on linux and win32:
            // - we have to spin the event loop,
            //   using nsIAppShell.run()
            // - therefore we have to execute initialization
            //   on a new thread, that will end with a call
            //   to nsIAppShell.run() that won't return

            if (platform==Platform.Linux) {
                try {
                    //initialize GTK, because mozilla code
                    //in nsIBaseWindow.initWindow assumes that
                    System.loadLibrary("gtkutilsjni");
                    GtkUtils.init();
                } catch (Throwable t) {
                    throw new MozillaException(t);
                }
            }

            //create lock for task completition
            final Semaphore taskLock = new Semaphore(1);
            try {
                taskLock.acquire();
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }

            //create mozilla thread
            final Throwable taskException[] = new Throwable[1];
            mozillaThread = new Thread() { @Override public void run() {
                try {
                    task.run();
                } catch (Throwable t) {
                    taskException[0] = t;
                } finally {
                    taskLock.release();
                }

                //spin the main event loop
                Mozilla moz = Mozilla.getInstance();
                nsIComponentManager componentManager = moz.getComponentManager();
                String NS_APPSHELL_CID = "{2d96b3df-c051-11d1-a827-0040959a28c9}"; //constant from mozilla/widget/public/nsWidgetsCID.h
                nsIAppShell appShell = (nsIAppShell) componentManager.createInstance(NS_APPSHELL_CID, null, nsIAppShell.NS_IAPPSHELL_IID);
                appShell.create(null, null);
                appShell.spinup();
                appShell.run();
            }};
            mozillaThread.setDaemon(true);
            mozillaThread.setName("Mozilla");
            mozillaThread.start();

            //wait for the initialization task to complete
            try {
                taskLock.acquire();
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }
            //forward an exception, if occured
            if (taskException[0]!=null)
                throw new MozillaException(taskException[0]);
        }

        //now the worker can start processing task queue
        singleton.initLock.release();
    }

    private static class MozCallable<V> implements nsIRunnable {

        private final Runnable task1;
        private final Callable<V> task2;
        private V result;
        private Throwable error;

        public MozCallable(Callable<V> task) {
            this.task1 = null;
            this.task2 = task;
        }

        public MozCallable(Runnable task) {
            this.task1 = task;
            this.task2 = null;
        }

        public void run() {
            //execute the job on mozilla thread
            if (task1==null && task2==null) return;
            try {
                if(task1!=null) task1.run();
                if(task2!=null) result = task2.call();
            } catch (Throwable t) {
                error = t;
            }
        }

        public nsISupports queryInterface(String uuid) {
            return Mozilla.queryInterface(this, uuid);
        }
    }


    private void syncExec(Runnable task)
        throws MozillaRuntimeException
    {
        if (isMozillaThread()) {
            try {
                task.run();
            } catch (Throwable e) {
                throw new MozillaRuntimeException("wrapped exception from mozilla task", e);
            }
        } else {
            MozCallable<Void> c = new MozCallable<Void>(task);
            nsIRunnable p = proxy(c, nsIRunnable.class);
            p.run();
            if (c.error!=null) throw new MozillaRuntimeException("wrapped exception from mozilla task", c.error);
            //return c.result;
        }
    }

    private void syncExec(RunnableEx task)
        throws MozillaException
    {
        if (isMozillaThread()) {
            try {
                task.call();
            } catch (Throwable e) {
                throw new MozillaException("wrapped exception from mozilla task", e);
            }
        } else {
            MozCallable<Void> c = new MozCallable<Void>(task);
            nsIRunnable p = proxy(c, nsIRunnable.class);
            p.run();
            if (c.error!=null) throw new MozillaException("wrapped exception from mozilla task", c.error);
            //return c.result;
        }
    }

    private <V> V syncExec(Callable<V> task)
        throws MozillaException
    {
        if (isMozillaThread()) {
            try {
                return task.call();
            } catch (Throwable e) {
                throw new MozillaException("wrapped exception from mozilla task", e);
            }
        } else {
            MozCallable<V> c = new MozCallable<V>(task);
            nsIRunnable p = proxy(c, nsIRunnable.class);
            p.run();
            if (c.error!=null) throw new MozillaException("wrapped exception from mozilla task", c.error);
            return c.result;
        }
    }

    private <V> MozCallable<V> asyncExec(Runnable task)
    {
        MozCallable<V> c = new MozCallable<V>(task);
        nsIRunnable p = asyncProxy(c, nsIRunnable.class);
        p.run();
        return c;
    }

    /**
     * Returns true, if the current thread is the mozilla thread,
     * that is a thread where (most of) the mozilla code runs.
     *
     * On OSX, mozilla thread is the AppKit thread.
     */
    public static boolean isMozillaThread() {
        return Thread.currentThread()==mozillaThread;
    }

    /**
     * Quietly and synchronously execute a task on mozilla thread.
     *
     * An exception caught during task exception, is re-thrown
     * wrapped in a subclass of the RuntimeException, so its
     * explicit handling is not enforced.
     */
    public static void mozSyncExec(Runnable task)
        throws MozillaRuntimeException
    {
        singleton.syncExec(task);
    }

    /**
     * Synchronously execute a task on mozilla thread.
     *
     * An exception caught during task exception, is re-thrown
     * wrapped in a MozillaException, so its explicit
     * handling is enforced.
     */
    public static void mozSyncExec(RunnableEx task)
        throws MozillaException
    {
        singleton.syncExec(task);
    }

    /**
     * Synchronously execute a task returning a result
     * on mozilla thread.
     *
     * An exception caught during task exception, is re-thrown
     * wrapped in a MozillaException, so its explicit
     * handling is enforced.
     */
    public static <V> V mozSyncExec(Callable<V> task)
        throws MozillaException
    {
        return singleton.syncExec(task);
    }

    /**
     * Asynchronously execute a task on mozilla thread.
     */
    public static MozCallable<Void> mozAsyncExec(Runnable task)
    {
        //FutureTask<Void> ft = new FutureTask<Void>(task, null);
        //return singleton.asyncExec(ft);
        //return ft;
        return singleton.asyncExec(task);
    }

    //used for debugging by a special patch in javaxpcom
    //see bug https://www.mozdev.org/bugs/show_bug.cgi?id=17706
    public static void logCurrentThread(Object o) {
        log.trace("thread="+Thread.currentThread()+" "+o);
        log.trace("called from:", new Exception());
    }

}
