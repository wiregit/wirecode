package org.mozilla.browser.examples;

import org.mozilla.browser.MozillaAutomation;
import org.mozilla.browser.MozillaPanel;
import org.mozilla.browser.MozillaWindow;
import org.mozilla.browser.impl.DOMUtils;
import org.w3c.dom.Document;

/**
 * Load a document and dump its DOM tree
 */
public class Example06_DOM {
    public static void main(String[] args) throws Exception {
        MozillaWindow win = new MozillaWindow();
        MozillaPanel moz = win.getPanel();
        win.addNotify();

        MozillaAutomation.blockingLoad(moz, "about:"); //$NON-NLS-1$

        Document doc = moz.getDocument();
        DOMUtils.writeDOMToStream(doc, System.out);

        System.exit(0);
    }
}
