package org.mozilla.browser.examples;

import java.awt.Image;

import org.mozilla.browser.IMozillaWindow;
import org.mozilla.browser.IMozillaWindowFactory;
import org.mozilla.browser.MozillaAutomation;
import org.mozilla.browser.MozillaPanel;
import org.mozilla.browser.MozillaWindow;
import org.mozilla.browser.impl.WindowCreator;
import org.mozilla.browser.impl.components.JImageButton;

/**
 * Customize creation of popup windows
 */
public class Example15_WindowFactory {

    public static void main(String[] args) {

        //load an icon
        final Image img = JImageButton.createImageIcon("reloadNormal.png").getImage(); //$NON-NLS-1$

        //set factory for creating new popup windows.
        //It must be set before creating the first MozillaWindow
        IMozillaWindowFactory f = new IMozillaWindowFactory() {
            public IMozillaWindow create(boolean attachBrowser) {
                MozillaPanel p = new MozillaPanel(attachBrowser);
                MozillaWindow w = new MozillaWindow(p);
                w.setIconImage(img);
                return w;
            }
        };
        WindowCreator.setWindowFactory(f);

        //use the icon for the main window
        MozillaWindow win = new MozillaWindow();
        MozillaPanel moz = win.getPanel();
        win.setIconImage(img);
        win.setSize(500, 600);
        win.setVisible(true);
        MozillaAutomation.blockingLoad(moz, "about:"); //$NON-NLS-1$

        //open a new popup window. It will have
        //the same icon
        moz.load("javascript:alert('dialog with the same icon')"); //$NON-NLS-1$
    }
}
