package org.mozilla.browser;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * A browser window.
 *
 * <p>Contains methods for loading HTML documents,
 * querying content and manipulating state of
 * a browser window.
 *
 * <p>A set of callbacks named on*() is available
 * that can be overriden to be notified about various
 * mozilla callbacks and/or modify the default MozSwing's
 * handled of these callbacks.
 *
 * <p>
 * Two implementations of IMozillaWindow are available:
 * <ul>
 * <li> {@link MozillaWindow} is a ready to use JFrame subclass suited
 *   for smaller swing applications or server-side applications
 * <li> {@link MozillaPanel} subclasses JPanel and is more suitable
 *   for embedding into larger swing application. However, you might
 *   need to adapt toolbar, statusbar or popup handling to fulfill
 *   requirements of your application.
 * </ul>
 */
public interface IMozillaWindow {

    /**
     * Returns title of this browser window
     *
     * @return window title
     */
    public String getTitle();
    /**
     * Sets title for this browser window
     *
     * @param title window title
     */
    public void setTitle(String title);
    /**
     * Returns insets of this container
     *
     * <p>See {@link JFrame#getInsets()}
     *
     * @return insets of this container
     */
    public Insets getInsets();
    /**
     * Returns position on the screen
     *
     * <p>See {@link JFrame#getLocationOnScreen()}
     * or {@link JPanel#getLocationOnScreen()}
     *
     * @return position on the screen
     */
    public Point getLocationOnScreen();
    /**
     * Returns size of the browser window. It includes size
     * of toolbar, status and for {@link MozillaWindow}
     * also window decoration.
     *
     * <p>See {@link JFrame#getSize()} or {@link JPanel#getSize()}
     *
     * @return size of the window
     */
    public Dimension getSize();
    /**
     * See {@link Component#isShowing()}
     *
     * @return true if the component is showing
     */
    public boolean isShowing();

    MozillaPanel getPanel();

    void setLocation(Point pos);

    void setSize(int w, int h);

    void setPreferredSize(Dimension d);

    void dispose();

    void setVisible(boolean visibility);

    boolean isVisible();
}
