package org.mozilla.browser;

import static org.mozilla.browser.MozillaExecutor.isMozillaThread;
import static org.mozilla.browser.MozillaExecutor.mozSyncExec;
import static org.mozilla.browser.MozillaExecutor.mozSyncExecQuiet;
import static org.mozilla.browser.XPCOMUtils.create;
import static org.mozilla.browser.XPCOMUtils.getService;
import static org.mozilla.browser.XPCOMUtils.qi;

import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;

import net.sourceforge.iharder.Base64;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mozilla.browser.impl.BlockingURLLoader;
import org.mozilla.browser.impl.ChromeAdapter;
import org.mozilla.interfaces.nsIBoxObject;
import org.mozilla.interfaces.nsIDOMAbstractView;
import org.mozilla.interfaces.nsIDOMCanvasRenderingContext2D;
import org.mozilla.interfaces.nsIDOMDocument;
import org.mozilla.interfaces.nsIDOMDocumentEvent;
import org.mozilla.interfaces.nsIDOMDocumentView;
import org.mozilla.interfaces.nsIDOMElement;
import org.mozilla.interfaces.nsIDOMEvent;
import org.mozilla.interfaces.nsIDOMEventTarget;
import org.mozilla.interfaces.nsIDOMHTMLCanvasElement;
import org.mozilla.interfaces.nsIDOMHTMLDocument;
import org.mozilla.interfaces.nsIDOMKeyEvent;
import org.mozilla.interfaces.nsIDOMMouseEvent;
import org.mozilla.interfaces.nsIDOMNSDocument;
import org.mozilla.interfaces.nsIDOMNSHTMLElement;
import org.mozilla.interfaces.nsIDOMWindow;
import org.mozilla.interfaces.nsIDOMXPathEvaluator;
import org.mozilla.interfaces.nsIDOMXPathResult;
import org.mozilla.interfaces.nsIDOMXULElement;
import org.mozilla.interfaces.nsISimpleEnumerator;
import org.mozilla.interfaces.nsIStringInputStream;
import org.mozilla.interfaces.nsIURI;
import org.mozilla.interfaces.nsIWebBrowser;
import org.mozilla.interfaces.nsIWebBrowserChrome;
import org.mozilla.interfaces.nsIWebNavigation;
import org.mozilla.interfaces.nsIWindowWatcher;

/**
 * Mozilla automation for junit test cases
 */
public class MozillaAutomation {

    static Log log = LogFactory.getLog(MozillaAutomation.class);

    /**
     * Loads an url into a mozilla window,
     * blocking until the load finishes or expires.
     */
    public static boolean blockingLoad(IMozillaWindow win, String url) {
        return blockingLoad(win, url, null);
    }


    /**
     * Loads an url into a mozilla window.
     * Additionally, POST data can be specified in
     * the format param1=val1&param2=val2...
     *
     * The function waits while the URL is loading and
     * returns only when loading is finished.
     *
     * Returns true if the load failed
     * (page does not exist)
     */
    public static boolean blockingLoad(IMozillaWindow win, final String url, final String postData) {
        if (isMozillaThread()) throw new RuntimeException(); //broken atm when calling from mozilla thread
        //log.debug("Loading document "+url);

        final nsIStringInputStream postDataStream;
        if (postData!=null) {
            try {
                postDataStream = create("@mozilla.org/io/string-input-stream;1", nsIStringInputStream.class);
                String streamData = String.format(
                    "Content-Type: application/x-www-form-urlencoded\r\n"+
                    "Content-Length: %d\r\n" +
                    "\r\n"+
                    "%s",
                    postData.getBytes("UTF-8").length,
                    postData);
                postDataStream.setData(streamData, -1);
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
        } else {
            postDataStream = null;
        }

        BlockingURLLoader l = new BlockingURLLoader(win) {
            @Override
            public boolean triggerURLLoading() {
                ChromeAdapter chromeAdapter = win.getChromeAdapter();
                if (chromeAdapter==null) return true;
                nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
                nav.loadURI(url, nsIWebNavigation.LOAD_FLAGS_NONE, null, postDataStream, null);
                return false;
            }
            @Override
            public void onLoadStarted() {}
            @Override
            public void onLoadEnded() {}
        };
        l.load();
        return l.getLoadFailed();
    }

    /**
     * Loads an url into a mozilla window.
     */
    public static boolean blockingLoadHTML(final IMozillaWindow win, final String content) {
        if (isMozillaThread()) throw new RuntimeException(); //broken atm when calling from mozilla thread
        //log.debug("Loading html content"+content);

        BlockingURLLoader l = new BlockingURLLoader(win) {
            @Override
            public boolean triggerURLLoading() {
                return triggerLoadHTML(win, content);
            }
            @Override
            public void onLoadStarted() {}
            @Override
            public void onLoadEnded() {}
        };
        l.load();
        return l.getLoadFailed();
    }

    /**
     * Triggers loading of web page with the give content.
     * Returns true if failed
     */
    public static boolean triggerLoadHTML(IMozillaWindow win, String content) {
        assert isMozillaThread();

        ChromeAdapter chromeAdapter = win.getChromeAdapter();
        if (chromeAdapter==null) return true;

        final String b64content;
        try {
            b64content = Base64.encodeBytes(content.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        final String dataURI = "data:text/html;base64,"+b64content;

        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIWebNavigation nav = qi(brow, nsIWebNavigation.class);
        nav.loadURI(dataURI, nsIWebNavigation.LOAD_FLAGS_NONE, null, null, null);
        return false;
    }

    /**
     * Load previous page in session history.
     * Method blocks until loading is completed.
     */
    public static boolean blockingBack(IMozillaWindow win) {
        if (isMozillaThread()) throw new RuntimeException(); //broken atm when calling from mozilla thread
        //log.debug("Go Back");
        BlockingURLLoader l = new BlockingURLLoader(win) {
            @Override
            public boolean triggerURLLoading() {
                ChromeAdapter chromeAdapter = win.getChromeAdapter();
                if (chromeAdapter==null) return true;
                nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
                nav.goBack();
                return false;
            }
            @Override
            public void onLoadStarted() {}
            @Override
            public void onLoadEnded() {}
        };
        l.load();
        return l.getLoadFailed();
    }

    /**
     * Load next page in session history.
     * Method blocks until loading is completed.
     */
    public static boolean blockingForward(IMozillaWindow win) {
        if (isMozillaThread()) throw new RuntimeException(); //broken atm when calling from mozilla thread
        //log.debug("Go Back");
        BlockingURLLoader l = new BlockingURLLoader(win) {
            @Override
            public boolean triggerURLLoading() {
                ChromeAdapter chromeAdapter = win.getChromeAdapter();
                if (chromeAdapter==null) return true;
                nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
                nav.goForward();
                return false;
            }
            @Override
            public void onLoadStarted() {}
            @Override
            public void onLoadEnded() {}
        };
        l.load();
        return l.getLoadFailed();
    }

    /**
     * Reload current page.
     * Method blocks until loading is completed.
     */
    public static boolean blockingReload(IMozillaWindow win) {
        if (isMozillaThread()) throw new RuntimeException(); //broken atm when calling from mozilla thread
        //log.debug("Go Back");
        BlockingURLLoader l = new BlockingURLLoader(win) {
            @Override
            public boolean triggerURLLoading() {
                ChromeAdapter chromeAdapter = win.getChromeAdapter();
                if (chromeAdapter==null) return true;
                nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
                nav.reload(nsIWebNavigation.LOAD_FLAGS_NONE);
                return false;
            }
            @Override
            public void onLoadStarted() {}
            @Override
            public void onLoadEnded() {}
        };
        l.load();
        return l.getLoadFailed();
    }

    public static String getCurrentURI(IMozillaWindow win) {
        assert isMozillaThread();

        nsIWebBrowser brow = win.getChromeAdapter().getWebBrowser();
        nsIWebNavigation nav = qi(brow, nsIWebNavigation.class);
        nsIURI uri = nav.getCurrentURI();
        return uri.getSpec();
    }

    /**
     * Clicks on a DOM element given by id.
     * Returns true, if failed.
     */
    public static boolean click(IMozillaWindow win, String id) {
        assert isMozillaThread();

        ChromeAdapter chromeAdapter = win.getChromeAdapter();
        if (chromeAdapter==null) return true;

        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIDOMDocument doc = brow.getContentDOMWindow().getDocument();

        nsIDOMElement elem = doc.getElementById(id);
        if (elem==null) return true;

        return click(elem);
    }

    /**
     * Clicks on a DOM element.
     * Returns true, if failed.
     */
    public static boolean click(nsIDOMElement elem) {
        assert isMozillaThread();

        //based on http://developer.mozilla.org/en/docs/DOM:document.createEvent
        nsIDOMDocument doc = elem.getOwnerDocument();
        nsIDOMDocumentEvent evdoc = qi(doc, nsIDOMDocumentEvent.class);
        nsIDOMEvent ev = evdoc.createEvent("MouseEvents");
        nsIDOMMouseEvent mev = qi(ev, nsIDOMMouseEvent.class);
        nsIDOMDocumentView view = qi(doc, nsIDOMDocumentView.class);
        nsIDOMAbstractView aview = view.getDefaultView();
        mev.initMouseEvent("click", true, true, aview, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        nsIDOMEventTarget evt = qi(elem, nsIDOMEventTarget.class);
        boolean canceled = !evt.dispatchEvent(mev);
        return canceled;
    }

    /**
     * Types text into a DOM element given by id.
     * Returns true, if failed.
     */
    public static boolean type(IMozillaWindow win, String id, String text) {
        assert isMozillaThread();

        ChromeAdapter chromeAdapter = win.getChromeAdapter();
        if (chromeAdapter==null) return true;

        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIDOMWindow domwin = brow.getContentDOMWindow();
        nsIDOMDocument doc = domwin.getDocument();

        nsIDOMElement elem = doc.getElementById(id);
        if (elem==null) return true;

        return type(elem, text);
    }

    /**
     * Simulates mousemove over a DOM element.
     * Returns true, if failed.
     */
    public static boolean mousemove(IMozillaWindow win, String id, float relX, float relY) {
        assert MozillaExecutor.isMozillaThread();

        ChromeAdapter chromeAdapter = win.getChromeAdapter();
        if (chromeAdapter==null) return true;

        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIDOMDocument doc = brow.getContentDOMWindow().getDocument();

        nsIDOMElement elem = doc.getElementById(id);
        if (elem==null) return true;

        return mousemove(elem, relX, relY);
    }

    /**
     * Simulates mousemove over a DOM element.
     * Returns true, if failed.
     */
    public static boolean mousemove(nsIDOMElement elem, float relX, float relY) {
        assert isMozillaThread();

        //based on http://developer.mozilla.org/en/docs/DOM:document.createEvent
        nsIDOMDocument doc = elem.getOwnerDocument();

        nsIDOMNSDocument nsdoc = qi(doc, nsIDOMNSDocument.class);
        nsIBoxObject box = nsdoc.getBoxObjectFor(elem);
        int sx = box.getScreenX();
        int sy = box.getScreenY();
        int h = box.getHeight();
        int w = box.getWidth();

        nsIDOMDocumentEvent evdoc = qi(doc, nsIDOMDocumentEvent.class);
        nsIDOMEvent ev = evdoc.createEvent("MouseEvents");
        nsIDOMMouseEvent mev = qi(ev, nsIDOMMouseEvent.class);
        nsIDOMDocumentView view = qi(doc, nsIDOMDocumentView.class);
        nsIDOMAbstractView aview = view.getDefaultView();

        int x = (int) (relX * w);
        int y = (int) (relY * h);
        if (x<0 || x>=w) x = 0;
        if (y<0 || y>=h) y = 0;

        //http://www.codingforums.com/showthread.php?t=21674
        mev.initMouseEvent("mousemove", true, true, aview, 0,
                           sx + x, sy + y,
                           x, y,
                           false, false, false, false, 0, null);
        nsIDOMEventTarget evt = qi(elem, nsIDOMEventTarget.class);
        boolean canceled = !evt.dispatchEvent(mev);
        return canceled;
    }

    /**
     * Types text into a DOM element.
     * Returns true, if failed.
     */
    public static boolean type(nsIDOMElement elem, String text) {
        assert isMozillaThread();

        //based on http://developer.mozilla.org/en/docs/DOM:event.initKeyEvent
        nsIDOMDocument doc = elem.getOwnerDocument();
        nsIDOMDocumentEvent evdoc = qi(doc, nsIDOMDocumentEvent.class);
        nsIDOMEvent ev = evdoc.createEvent("KeyboardEvent");
        nsIDOMKeyEvent mev = qi(ev, nsIDOMKeyEvent.class);
        nsIDOMDocumentView view = qi(doc, nsIDOMDocumentView.class);
        nsIDOMAbstractView aview = view.getDefaultView();
        for (int i=0; i<text.length(); i++) {
            char c = text.charAt(i);
            mev.initKeyEvent("keypress", true, true, aview, false, false, false, false, 0, c);
            nsIDOMEventTarget evt = qi(elem, nsIDOMEventTarget.class);
            boolean canceled = !evt.dispatchEvent(mev);
            if (canceled) return canceled;
        }
        return false;
    }

    /**
     * Wait at most waitMillis until a window with title winTitle is open
     */
    public static IMozillaWindow waitForWindowWithTitle(String winTitle, int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        List<IMozillaWindow> wins = waitForNumWindowsWithTitle(winTitle, 1, waitMillis);
        return wins.isEmpty()?null:wins.get(0);
    }

    /**
     * Wait at most waitMillis until numWins windows with title winTitle are open
     */
    public static List<IMozillaWindow> waitForNumWindowsWithTitle(final String winTitle, int numWins, int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        final List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        mozSyncExec(new Runnable() { public void run() {
            wins.clear();
            wins.addAll(findWindowsByTitle(winTitle));
        }});

        int waited = 0;
        while (wins.size()<numWins && waited<waitMillis) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }
            waited += 300;

            mozSyncExec(new Runnable() { public void run() {
                wins.clear();
                wins.addAll(findWindowsByTitle(winTitle));
            }});
        }

        return wins;
    }

    public static IMozillaWindow waitForNoWindowWithTitle(final String winTitle, int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        final List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        mozSyncExec(new Runnable() { public void run() {
            wins.clear();
            wins.addAll(findWindowsByTitle(winTitle));
        }});

        int waited = 0;
        while (!wins.isEmpty() && waited<waitMillis) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }
            waited += 300;

            mozSyncExec(new Runnable() { public void run() {
                wins.clear();
                wins.addAll(findWindowsByTitle(winTitle));
            }});
        }

        return wins.isEmpty()?null:wins.get(0);
    }


    /**
     * Wait at most waitMillis until a window containing
     * a node with nodeText is open
     */
    public static IMozillaWindow waitForWindowWithNodeText(String nodeText, int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        List<IMozillaWindow> wins = waitForNumWindowsWithNodeText(nodeText, 1, waitMillis);
        return wins.isEmpty()?null:wins.get(0);
    }

    /**
     * Wait at most waitMillis until numWins windows containing
     * a node with nodeText are open
     */
    public static List<IMozillaWindow>
        waitForNumWindowsWithNodeText(final String nodeText,
                                      int numWins,
                                      int waitMillis)
    {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        final List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        mozSyncExec(new Runnable() { public void run() {
            wins.clear();
            wins.addAll(findWindowsByNodeText(nodeText));
        }});

        int waited = 0;
        while (wins.size()<numWins && waited<waitMillis) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }
            waited += 300;

            mozSyncExec(new Runnable() { public void run() {
                wins.clear();
                wins.addAll(findWindowsByNodeText(nodeText));
            }});
        }

        return wins;
    }

    public static IMozillaWindow waitForNoWindowWithNodeText(final String nodeText, int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();

        final List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        mozSyncExec(new Runnable() { public void run() {
            wins.clear();
            wins.addAll(findWindowsByNodeText(nodeText));
        }});

        int waited = 0;
        while (!wins.isEmpty() && waited<waitMillis) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                log.error("wait interrupted", e);
            }
            waited += 300;

            mozSyncExec(new Runnable() { public void run() {
                wins.clear();
                wins.addAll(findWindowsByNodeText(nodeText));
            }});
        }

        return wins.isEmpty()?null:wins.get(0);
    }

    public static void sleep(int waitMillis) {
        //can't wait on mozilla thread
        assert !isMozillaThread();
        try {
            Thread.sleep(waitMillis);
        } catch (InterruptedException e) {
            log.error("wait interrupted", e);
        }
    }

    public static List<IMozillaWindow> findWindowsByTitle(String winTitle) {
        assert isMozillaThread();

        List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsISimpleEnumerator en = winWatcher.getWindowEnumerator();
        while (en.hasMoreElements()) {
            nsIDOMWindow domWin = qi(en.getNext(), nsIDOMWindow.class);
            if (domWin==null) continue;

            String title = null;
            nsIDOMHTMLDocument htmlDoc = qi(domWin.getDocument(), nsIDOMHTMLDocument.class);
            if (htmlDoc!=null) {
                title = htmlDoc.getTitle();
            } else {
                nsIDOMNSDocument nsDoc = qi(domWin.getDocument(), nsIDOMNSDocument.class);
                if (nsDoc!=null) {
                    title = nsDoc.getTitle();
                }
            }

            if (title!=null && winTitle.equals(title)) {
                IMozillaWindow win = findWindow(domWin);
                if (win!=null) wins.add(win);
            }
        }

        return wins;
    }

    public static List<IMozillaWindow> findWindowsByNodeText(String nodeText) {
        assert isMozillaThread();

        List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();
        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsISimpleEnumerator en = winWatcher.getWindowEnumerator();
        while (en.hasMoreElements()) {
            nsIDOMWindow domWin = qi(en.getNext(), nsIDOMWindow.class);
            if (domWin==null) continue;

            nsIDOMDocument doc = domWin.getDocument();
            nsIDOMXPathEvaluator eval = qi(doc, nsIDOMXPathEvaluator.class);
            nsIDOMXPathResult ret = qi(eval.evaluate("count(//*[text()='"+nodeText+"'])"/*[text()=='"+nodeText+"'"*/, doc, null, nsIDOMXPathResult.ANY_TYPE, null), nsIDOMXPathResult.class);
            double count = ret.getNumberValue();

            if (count>0d) {
                IMozillaWindow win = findWindow(domWin);
                if (win!=null) wins.add(win);
            }
        }

        return wins;
    }

    public static IMozillaWindow findWindowByName(String winName) {
        assert isMozillaThread();

        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsIDOMWindow domWin = winWatcher.getWindowByName(winName, null);
        if (domWin==null) return null;
        return findWindow(domWin);
    }

    public static IMozillaWindow findWindow(nsIDOMWindow domWin) {
        assert isMozillaThread();

        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsIWebBrowserChrome chromeWin = winWatcher.getChromeForWindow(domWin);
        if (chromeWin==null) return null;
        return findWindow(chromeWin);
    }

    public static IMozillaWindow findWindow(nsIWebBrowserChrome chromeWin) {
        assert isMozillaThread();

        ChromeAdapter wina = (ChromeAdapter) chromeWin;
        return wina.getWindow();
    }

    public static void dumpWindows() {
        assert isMozillaThread();

        List<String> winTitles = new LinkedList<String>();
        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsISimpleEnumerator en = winWatcher.getWindowEnumerator();
        while (en.hasMoreElements()) {
            nsIDOMWindow domWin = qi(en.getNext(), nsIDOMWindow.class);
            if (domWin==null) continue;

            String title = null;
            nsIDOMHTMLDocument htmlDoc = qi(domWin.getDocument(), nsIDOMHTMLDocument.class);
            if (htmlDoc!=null) {
                title = htmlDoc.getTitle();
            } else {
                nsIDOMNSDocument nsDoc = qi(domWin.getDocument(), nsIDOMNSDocument.class);
                if (nsDoc!=null) {
                    title = nsDoc.getTitle();
                }
            }

            winTitles.add(title!=null?title:"<none>");
        }

        StringBuffer sb = new StringBuffer();
        for (String s : winTitles) {
            sb.append(", ");
            sb.append(s);
        }
        log.debug(sb.toString());
    }


    public static List<IMozillaWindow> getOpennedWindows() {
        assert isMozillaThread();

        List<IMozillaWindow> wins = new LinkedList<IMozillaWindow>();

        nsIWindowWatcher winWatcher = getService("@mozilla.org/embedcomp/window-watcher;1", nsIWindowWatcher.class);
        nsISimpleEnumerator en = winWatcher.getWindowEnumerator();
        while (en.hasMoreElements()) {
            nsIDOMWindow domWin = qi(en.getNext(), nsIDOMWindow.class);
            if (domWin==null) continue;

            IMozillaWindow win = findWindow(domWin);
            wins.add(win);
        }

        return wins;
    }

//    public static void processPending() {
//        processPending(0);
//    }
//    public static void processPending(int millis) {
//        long start = System.currentTimeMillis();
//        nsIEventQueueService eqs = getService("@mozilla.org/event-queue-service;1", nsIEventQueueService.class);
//        nsIEventQueue currentThreadQ = eqs.getSpecialEventQueue(nsIEventQueueService.CURRENT_THREAD_EVENT_QUEUE);
//        //process events until we're finished.
//        while (true) {
//            if (currentThreadQ.pendingEvents())
//                currentThreadQ.processPendingEvents();
//
//            if (System.currentTimeMillis()-start>=millis) {
//                break;
//            }
//        }
//    }

    public static Object executeJavascript(final IMozillaWindow win, final String script) {
        final Object[] ret = new Object[1];
        mozSyncExec(new Runnable() { public void run() {
            ChromeAdapter chromeAdapter = win.getChromeAdapter();
            if (chromeAdapter==null) return;
            nsIWebNavigation nav = qi(chromeAdapter.getWebBrowser(), nsIWebNavigation.class);
            nav.loadURI("javascript:void "+script, nsIWebNavigation.LOAD_FLAGS_NONE, null, null, null);
            /*better implementation with return values
            ::Evaluate(nsIDOMWindow* aWindow, const nsAString& aCode, nsIVariant** _retval)
            {
            nsCOMPtr<nsIScriptGlobalObject> global(do_QueryInterface(aWindow));
              if (!global)
                return NS_ERROR_UNEXPECTED;

              nsIScriptContext* context = global->GetContext();
              if (!context)
                return NS_ERROR_UNEXPECTED;

              nsCOMPtr<nsIXPConnect> xpc(do_GetService(kXPCCID));
              if (!xpc)
                return NS_ERROR_UNEXPECTED;

              JSContext* cx = NS_STATIC_CAST(JSContext*, context->GetNativeContext());
              NS_ASSERTION(cx, "no context?");

              jsval rval = JSVAL_VOID;
              JSAutoTempValueRooter tvr(cx, 1, &rval);

              PRBool isUndefined;
              nsresult rv = context->EvaluateStringWithValue(aCode, nsnull, nsnull,
                                                             nsnull, 0, nsnull, &rval,
                                                             &isUndefined);
              if (NS_FAILED(rv))
                return rv;

              if (isUndefined || JSVAL_IS_NULL(rval)) {
                *_retval = nsnull;
              } else {
                rv = xpc->JSToVariant(cx, rval, _retval);
              }

              return rv;
            }

            nsIWebBrowser brow = win.getChromeAdapter().getWebBrowser();
            nsIDOMWindow domWin = brow.getContentDOMWindow();
            nsIVariant variant = jseval(domWin, script);

            switch (v.getDataType();) {
            case VTYPE_INT8: return var.getAsInt8(v);
            case VTYPE_INT16: return var.getAsInt16(v);
            case VTYPE_INT32: return var.getAsInt32(v);
            case VTYPE_INT64: return var.getAsInt64(v);
            case VTYPE_UINT8: return var.getAsUint8(v);
            case VTYPE_UINT16: return var.getAsUint16(v);
            case VTYPE_UINT32: return var.getAsUint32(v);
            case VTYPE_UINT64: return var.getAsUint64(v);
            case VTYPE_FLOAT: return var.getAsFloat(v);
            case VTYPE_DOUBLE: return var.getAsDouble(v);
            case VTYPE_BOOL: return var.getAsBool(v);
            case VTYPE_CHAR: return var.getAsChar(v);
            case VTYPE_WCHAR: return var.getAsWChar(v);
            case VTYPE_VOID: return null;
            case VTYPE_ID: throw new MozillaRuntimeException("unsupported javascript return type");
            case VTYPE_DOMSTRING: return var.getAsDOMString(v);
            case VTYPE_CHAR_STR: return var.getAsAUTF8String(v); //conversion
            case VTYPE_WCHAR_STR: return var.getAsWString(v);
            case VTYPE_INTERFACE: throw new MozillaRuntimeException("unsupported javascript return type");
            case VTYPE_INTERFACE_IS: throw new MozillaRuntimeException("unsupported javascript return type");
            case VTYPE_ARRAY: throw new MozillaRuntimeException("unsupported javascript return type");
            case VTYPE_STRING_SIZE_IS: return var.getAsStringWithSize(v);
            case VTYPE_WSTRING_SIZE_IS: return var.getAsWStringWithSize(v);
            case VTYPE_UTF8STRING: return var.getAsAUTF8String(v);
            case VTYPE_CSTRING: return var.getAsACString(v);
            case VTYPE_ASTRING: return var.getAsAString(v);
            case VTYPE_EMPTY_ARRAY: return new Object[0];
            case VTYPE_EMPTY: return null;
            default: return null;
        }

            */
        }});
        return ret[0];
    }

    /**
     * Renders content of the given window to an PNG image
     */
    public static byte[] renderToImage(final IMozillaWindow win) {
        final MozillaWindow hiddenWin = new MozillaWindow();
        hiddenWin.addNotify();

        String b64data =
            mozSyncExecQuiet(new Callable<String>() { public String call() {
                //create a hidden browser window with <canvas> element
                nsIWebBrowser wb = hiddenWin.getChromeAdapter().getWebBrowser();
                nsIDOMDocument doc = wb.getContentDOMWindow().getDocument();
                nsIDOMElement elem = doc.createElementNS("http://www.w3.org/1999/xhtml", "html:canvas");
                nsIDOMHTMLCanvasElement canvas = qi(elem, nsIDOMHTMLCanvasElement.class);
                nsIDOMCanvasRenderingContext2D context = qi(canvas.getContext("2d"), nsIDOMCanvasRenderingContext2D.class);

                nsIDOMWindow domWin = win.getChromeAdapter().getWebBrowser().getContentDOMWindow();
                //find out size of the document to be rendered
                int w, h;
                nsIDOMNSHTMLElement nselem = qi(domWin.getDocument().getDocumentElement(), nsIDOMNSHTMLElement.class);
                if (nselem!=null) {
                    w =
                        nselem.getOffsetWidth()>nselem.getScrollWidth() ?
                        nselem.getOffsetWidth() : nselem.getScrollWidth();
                    h =
                        nselem.getOffsetHeight()>nselem.getScrollHeight() ?
                        nselem.getOffsetHeight() : nselem.getScrollHeight();
                } else {
                    nsIDOMXULElement xulelem = qi(domWin.getDocument().getDocumentElement(), nsIDOMXULElement.class);
                    if (xulelem!=null) {
                        try {
                            w = Integer.parseInt(xulelem.getWidth());
                            h = Integer.parseInt(xulelem.getHeight());
                        } catch (NumberFormatException e) {
                            w = h = 1000;
                        }
                    } else {
                        w = h = 1000;
                    }
                }
                if (h>16384) h=16384; //limits in canvas in code

                //fit canvas size to the content and
                //render the document there
                canvas.setWidth(w);
                canvas.setHeight(h);
                context.drawWindow(domWin, 0, 0, w, h, "rgb(255,255,255)");

                //get content of the canvas as png image
                return canvas.toDataURLAs("image/png", "");
            }});
        b64data = b64data.replaceAll("^data:image/png;base64,", "");
        try {
            byte[] data = Base64.decode(b64data);

//            FileOutputStream fos = new FileOutputStream("img-"+System.currentTimeMillis()+".png");
//            fos.write(data);
//            fos.close();
            return data;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
