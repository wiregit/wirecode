/**
 * 
 */
package org.mozilla.browser.common;

public enum Platform {
    OSX("macosx"), Linux("linux"), Win32("win32"), Solaris("solaris");

    public static final Platform platform;
    public static final String arch;

    //http://lopica.sourceforge.net/os.html
    //mapping of known os.name:os.arch combinations to xulrunner location
    //  SunOS:x86 --> solaris-x86
    
    static {
        String osname = System.getProperty("os.name");
        if ("Mac OS X".equals(osname)) {
            platform = Platform.OSX;
        } else if ("Linux".equals(osname)) {
            platform = Platform.Linux;
        } else if ("SunOS".equals(osname)) {
            platform = Platform.Solaris;
        } else {
            platform = Platform.Win32;
        }

        String osarch = System.getProperty("os.arch");
        String archTemp = osarch;
        for (String x : new String[]{"i386", "i486", "i586", "i686"}) {
            if (x.equals(osarch)) {
                archTemp = "x86";
                break;
            }
        }
        arch = archTemp;
    }

    private final String libDir;

    private Platform(String libDir) {
        this.libDir = libDir;
    }

    public String libDir() {
        return libDir;
    }
    
    public String arch() {        
        return arch;
    }
    
    public static boolean usingGTK2Toolkit() {
        return platform==Linux || platform==Solaris;
    }
}