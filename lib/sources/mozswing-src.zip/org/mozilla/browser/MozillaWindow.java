package org.mozilla.browser;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Browser window.
 *
 * <p> MozillaWindow is a ready to use JFrame subclass suited
 * for smaller swing applications or server-side applications.
 * It implements GUI of standard browser window with
 * toolbar and statusbar and handles HTML popups.
 *
 * <p>Therefore, creating a browser in your code is as simple as:
 * <code>
 * <pre>
 *   MozillaWindow w = new MozillaWindow();
 *   w.setBounds(200, 200, 1024, 768);
 *   w.load("about:");
 *   w.setVisible(true);
 * </pre>
 * </code>
 *
 * <p>The result is displayed on the picture bellow:</p>
 * <img src="http://sourceforge.net/dbimage.php?id=150841"></img>
 * <p>
 */
public class MozillaWindow
    extends JFrame
    implements IMozillaWindow
{
    private static final long serialVersionUID = 1L;

    static Log log = LogFactory.getLog(MozillaWindow.class);

    protected MozillaPanel panel;

    /**
     * Creates a new MozillaWindow with a new MozillaPanel inside.
     */
    public MozillaWindow() {
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        this.panel = new MozillaPanel(this, true, null, null);
        add(panel, BorderLayout.CENTER);
    }

    /**
     * Creates a new MozillaWindow with the given MozillaPanel inside.
     *
     * @param panel mozilla panel to embed in this window
     */
    public MozillaWindow(MozillaPanel panel)
    {
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        this.panel = panel;
        panel.setContainerWindow(this);
        add(panel, BorderLayout.CENTER);
    }

    public MozillaPanel getPanel() {
        return panel;
    }

    @SuppressWarnings("all") //javadoc only - how? //$NON-NLS-1$
    public static void main(String[] args) throws Exception {
        String url = "about:"; //$NON-NLS-1$
        if (args.length>=2 &&
            (args[0].equals("-url") || //$NON-NLS-1$
             args[0].equals("--url"))) //$NON-NLS-1$
        {
            url = args[1];
        }

        MozillaWindow frame = new MozillaWindow();
        MozillaPanel moz = frame.getPanel();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200, 200, 1024, 768);
        //moz.load(MozillaTest.resolveURL("popup.html"));
        moz.load(url);
        frame.setVisible(true);
    }

}
