package org.mozilla.browser.impl;

import static org.mozilla.browser.MozillaExecutor.isMozillaThread;
import static org.mozilla.browser.MozillaExecutor.mozAsyncExec;
import static org.mozilla.browser.MozillaExecutor.swingAsyncExec;
import static org.mozilla.browser.XPCOMUtils.qi;

import java.awt.Canvas;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.SwingUtilities;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mozilla.browser.MozillaConfig;
import org.mozilla.browser.common.Platform;
import org.mozilla.interfaces.nsIBaseWindow;
import org.mozilla.interfaces.nsIDOMElement;
import org.mozilla.interfaces.nsIDOMEvent;
import org.mozilla.interfaces.nsIDOMEventListener;
import org.mozilla.interfaces.nsIDOMEventTarget;
import org.mozilla.interfaces.nsIDOMHTMLAnchorElement;
import org.mozilla.interfaces.nsIDOMWindow2;
import org.mozilla.interfaces.nsISupports;
import org.mozilla.interfaces.nsIWebBrowser;
import org.mozilla.interfaces.nsIWebBrowserFocus;
import org.mozilla.xpcom.Mozilla;
import org.mozilla.xpcom.XPCOMException;

public class MozillaCanvas extends Canvas
{

    private static final long serialVersionUID = 2946773219993586110L;

    static Log log = LogFactory.getLog(MozillaCanvas.class);

    private ChromeAdapter chromeAdapter;

    public MozillaCanvas() {
    }

    private long mozHandle = 0;
    private long gtkPtr = 0;

    private CanvasListener canvasListener;
    private WindowListener windowListener;

    public long createHandle(Rectangle dim) {
        assert isMozillaThread();
        Mozilla moz = Mozilla.getInstance();
        if (Platform.usingGTK2Toolkit()) {
            Toolkit.getDefaultToolkit().sync();
            //Mozilla assumes a top-level GTK window exists.
            //
            //So, we create one with GtkPlug widget. This
            //widget is hooked as a child of the AWT canvas
            //using the XEMBED protocol.
            //
            //The implementation of XEMBED/Server mode
            //for the AWT canvas is not fully implemented (in java6),
            //so we have to take care of handling resize/show/hide
            //events
            int awtID = (int) moz.getNativeHandleFromAWT(this);
            assert awtID!=0;
            if (Platform.platform==Platform.Solaris) {
                //XEmbed implementation on solaris seems to be broken
                gtkPtr = GtkUtils.windowNew();    
            } else {
                //on Linux use XEmbed, it handles focus
                //and keyevent propagation
                gtkPtr = GtkUtils.plugNew(awtID);
            }
            assert gtkPtr!=0;
            Toolkit.getDefaultToolkit().sync();
            GtkUtils.widgetSetUSize(gtkPtr, dim.width, dim.height);
            GtkUtils.widgetShow(gtkPtr);
            Toolkit.getDefaultToolkit().sync();
            if (Platform.platform==Platform.Solaris) {
                GtkUtils.reparentWindow(awtID, gtkPtr);
            }
            mozHandle = gtkPtr;
        } else {
            long h = moz.getNativeHandleFromAWT(this);
            assert h!=0;
            mozHandle = h;
        }

        return mozHandle;
    }

    public void destroyHandle() {
        assert isMozillaThread();
        if (Platform.usingGTK2Toolkit()) {
            GtkUtils.widgetDestroy(gtkPtr);
            gtkPtr = 0;
        }
        mozHandle = 0;
    }

    public long getHandle() {
        return mozHandle;
    }

    public void addNotify() {
        super.addNotify();
        canvasListener = new CanvasListener();
        addComponentListener(canvasListener);

        Window win = SwingUtilities.getWindowAncestor(this);
        assert win!=null;
        windowListener = new WindowListener(win);
        win.addComponentListener(windowListener);
        win.addWindowFocusListener(windowListener);
        win.addWindowListener(windowListener);

        setFocusable(true);
    }

    private class CanvasListener implements ComponentListener
    {
        public void componentHidden(ComponentEvent e) {
            //never called, so we have to register
            //on window ancestor
        }
        public void componentShown(ComponentEvent e) {
            //never called, so we have to register
            //on window ancestor
        }
        public void componentResized(ComponentEvent e) {
            onResize();
        }
        public void componentMoved(ComponentEvent e) {}
    }

    private class WindowListener
        extends WindowAdapter
        implements
            ComponentListener,
            WindowFocusListener
    {
        private final Window win;

        public WindowListener(Window win) {
            this.win = win;
        }

        public void componentHidden(ComponentEvent e) {
            onHide();
        }
        public void componentShown(ComponentEvent e) {
            onShow();
        }
        public void componentResized(ComponentEvent e) {}
        public void componentMoved(ComponentEvent e) {}

        public void windowGainedFocus(WindowEvent e) {}
        public void windowLostFocus(WindowEvent e) {}

        Component lastFocusedCmpOnDeactivate = null;
        public void windowActivated(WindowEvent e) {
            log.debug("window activated, lastWas: "+lastFocusedCmpOnDeactivate);
            onFocusMovedTo(lastFocusedCmpOnDeactivate);
        }


        public void windowDeactivated(WindowEvent e) {
            log.debug("window deactivated");
            lastFocusedCmpOnDeactivate = lastFocusedCmp;
            onFocusMovedTo(null);
        }
    }

    @Override
    public void removeNotify() {
        if (canvasListener!=null) {
            removeComponentListener(canvasListener);
            canvasListener = null;
        }
        if (windowListener!=null) {
            windowListener.win.removeComponentListener(windowListener);
            windowListener.win.removeWindowFocusListener(windowListener);
            windowListener.win.removeWindowListener(windowListener);
            windowListener = null;
        }

        mozAsyncExec(new Runnable() { public void run() {
            if (chromeAdapter==null) return;
            chromeAdapter.destroyBrowserWindow();
        }});

        super.removeNotify();
    }

//    public void doDestroy() {
//        if (webBrowser!=null) {
//            if (MozillaExecutor.isMozillaThread()) {
//                //unregister progress listener
//                webBrowser.removeWebBrowserListener(win.mpa, nsIWebProgressListener.NS_IWEBPROGRESSLISTENER_IID);
////                if (win.ma.inModalLoop) {
////                    win.ma.exitModalEventLoop(NS_OK);
////                }
//            } else {
//                final nsIWebBrowser[] cached = new nsIWebBrowser[] { webBrowser };
//                mozAsyncExec(new Runnable() { public void run() {
////                    if (win.ma.inModalLoop) {
////                        win.ma.exitModalEventLoop(NS_OK);
////                    }
//                    cached[0].removeWebBrowserListener(win.mpa, nsIWebProgressListener.NS_IWEBPROGRESSLISTENER_IID);
//                    cached[0].getContainerWindow().destroyBrowserWindow();
//                    cached[0] = null;
//                    forceGC();
//                }});
//            }
//            //release reference to the webbrowser instance
//            //so that the webshell/docshell can be destroyed
//            webBrowser = null;
//            //force GC to release components of the window on
//            //the native side. This will also unregister the
//            //window from window watcher
//            forceGC();
//            //GtkUtils.destroyWindow(gtkPtr);
//        }
//    }

//    public void forceGC() {
//        //we have to try long enough for
//        //the gc to really execute
//        for (int i=0; i<3; i++) {
//            //trigger gc
//            System.gc();
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException e) {
//                log.error("wait interrupted", e);
//            }
//        }
//    }

    private void onShow() {
        log.trace("onShow");
        // set the visibility on the thing
        if (chromeAdapter==null) return;
        Toolkit.getDefaultToolkit().sync();
        mozAsyncExec(new Runnable() { public void run() {
            Toolkit.getDefaultToolkit().sync();
            if (chromeAdapter==null) return;
            nsIBaseWindow baseWindow = qi(chromeAdapter.getWebBrowser(), nsIBaseWindow.class);
            baseWindow.setVisibility(true);
        }});
    }

    private void onHide() {
        log.trace("onHide");
        if (chromeAdapter==null) return;
        Toolkit.getDefaultToolkit().sync();
        // set the visibility on the thing
        mozAsyncExec(new Runnable() { public void run() {
            Toolkit.getDefaultToolkit().sync();
            if (chromeAdapter==null) return;
            nsIBaseWindow baseWindow = qi(chromeAdapter.getWebBrowser(), nsIBaseWindow.class);
            baseWindow.setVisibility(false);
        }});
    }

    private void onResize() {
        log.trace("onResize");
        if (chromeAdapter==null) return;
        Toolkit.getDefaultToolkit().sync();
        //sync exec deadlocks on OSX when manually resizing window
        mozAsyncExec(new Runnable() { public void run() {
            Toolkit.getDefaultToolkit().sync();
            Rectangle rect = getBounds();
            //sometimes (e.g. when opening javascript:
            //the height is be negative
            if (rect.isEmpty()) return;
            if (chromeAdapter==null) return;
            nsIBaseWindow baseWindow = qi(chromeAdapter.getWebBrowser(), nsIBaseWindow.class);
            baseWindow.setPositionAndSize(rect.x, rect.y, rect.width, rect.height, true);
            if (Platform.usingGTK2Toolkit() && gtkPtr!=0) {
                GtkUtils.widgetSetUSize(gtkPtr, rect.width, rect.height);
            }
        }});
    }

    public void onAttachBrowser(ChromeAdapter chromeAdapter) {
        assert chromeAdapter!=null;
        assert this.chromeAdapter==null;

        this.chromeAdapter = chromeAdapter;

        //On osx, when user clicks on a textfield,
        // in the mozarea, mozilla paints focus
        //in that textfield.
        //
        //We are supposed to call activate(), but
        //I do not know a good way of listening
        //for that event.
        //
        //For example, GtkEmbed does this with hooking
        //on focus_in_event signal but this does not work
        //in our case because of using the GtkPlug or
        //XReparentWindow
        //
        //Also, there are events DOMFocusIn, DOMFocusOut, DOMActivate
        //but mozilla (xul1.8.1) does not send them correctly
        //
        //So, we listen for all mousedown events, and activate
        //mozarea on such event.
        //Activation on traversal keys (e.g. <Tab>) are
        //handled via onFocusMovedTo.
        if (hasFocus()) {
            //sync state
            onFocusMovedTo(this);
        }
        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIDOMWindow2 win = qi(brow.getContentDOMWindow(), nsIDOMWindow2.class);
        nsIDOMEventTarget et = win.getWindowRoot();
        et.addEventListener("mousedown", ml, false);
        //listen when focus moves to another swing component
        FocusWatcher.register(this);

        //sync with the enabled images flag
        if (!MozillaConfig.isEnabledImages()) {
            MozillaConfig.disableImages(chromeAdapter.getWindow());
        }

        //synchronize with current visibility state
        boolean vis = isVisible();
        nsIBaseWindow baseWindow = qi(chromeAdapter.getWebBrowser(), nsIBaseWindow.class);
        baseWindow.setVisibility(vis);
    }

    public void onDetachBrowser() {
        nsIWebBrowser brow = chromeAdapter.getWebBrowser();
        nsIDOMWindow2 win = qi(brow.getContentDOMWindow(), nsIDOMWindow2.class);
        nsIDOMEventTarget et = win.getWindowRoot();
        et.removeEventListener("mousedown", ml, false);
        FocusWatcher.unregister(this);

        this.chromeAdapter = null;
    }

    private class MozMouseListener implements nsIDOMEventListener {
        public void handleEvent(nsIDOMEvent ev) {
            log.debug("dom event "+ev.getType());
            swingAsyncExec(new Runnable() { public void run() {
                if (lastFocusedCmp!=MozillaCanvas.this) {
                    MozillaCanvas.this.requestFocus();
                }
            }});
        }
        public nsISupports queryInterface(String uuid) {
            return Mozilla.queryInterface(this, uuid);
        }
    }
    private final MozMouseListener ml = new MozMouseListener();

    Component lastFocusedCmp = null;
    public void onFocusMovedTo(Component cmp) {
        if (cmp==lastFocusedCmp) return;
        log.debug("focus moved to: "+
                 (lastFocusedCmp==null?null:lastFocusedCmp.getClass().getSimpleName())+
                 " -> "+
                 (cmp==null?null:cmp.getClass().getSimpleName()));

        if (cmp==this) {
            if (lastFocusedCmp!=this && chromeAdapter!=null) {
                mozAsyncExec(new Runnable() { public void run() {
                    if (chromeAdapter==null) return;
                    nsIWebBrowserFocus webBrowserFocus = qi(chromeAdapter.getWebBrowser(), nsIWebBrowserFocus.class);
                    webBrowserFocus.activate();
                    log.debug("-------mozilla activated");
                }});
            }
        } else {
            if (lastFocusedCmp==this && chromeAdapter!=null) {
                mozAsyncExec(new Runnable() { public void run() {
                    if (chromeAdapter==null) return;
                    nsIWebBrowserFocus webBrowserFocus = qi(chromeAdapter.getWebBrowser(), nsIWebBrowserFocus.class);

                    if (Platform.platform==Platform.OSX) {
                        //this code does not work on win32
                        //
                        //if clicking away from a focuse <a> element, into
                        //a JTextfield, mozilla does not un-paint the the
                        //dotted rectangle, so do that manually
                        try {
                            log.debug("blurring");
                            nsIDOMElement el = webBrowserFocus.getFocusedElement();
                            log.debug("el="+el);
                            nsIDOMHTMLAnchorElement ael = qi(el, nsIDOMHTMLAnchorElement.class);
                            if (ael!=null) {
                                ael.blur();
                                log.debug("-------link blurred");
                            }
                        } catch (XPCOMException e) {
                            //ignore
                        }
                    }

                    webBrowserFocus.deactivate();
                    log.debug("-------mozilla deactivated");

                }});
            }
        }

        lastFocusedCmp = cmp;
    }

}
